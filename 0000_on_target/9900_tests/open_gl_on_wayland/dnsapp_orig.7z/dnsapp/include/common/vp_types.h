/************************************************************************************************/
/* name         : vp_types.h																	*/
/* description  : Definitions of the basic data type by the VisioPark project					*/
/*																								*/
/* Copyright(C) DENSO Corporation																*/
/*																								*/
/************************************************************************************************/
#ifndef VP_TYPES_H
#define VP_TYPES_H

/*==============================================================================================*/
/* Includes																						*/
/*==============================================================================================*/

/*==============================================================================================*/
/* Defines																						*/
/*==============================================================================================*/

/*==============================================================================================*/
/* Macro Functions																				*/
/*==============================================================================================*/
typedef signed char					S1;		/* Signed 1byte data type				*/
typedef signed short				S2;		/* Signed 2byte data type				*/
typedef signed long					S4;		/* Signed 4byte data type				*/
typedef unsigned char				U1;		/* Unsigned 1byte data type				*/
typedef unsigned short				U2;		/* Unsigned 2byte data type				*/
typedef unsigned long				U4;		/* Unsigned 4byte data type				*/
typedef volatile signed char		VS1;	/* Volatile signed 1byte data type		*/
typedef volatile signed short		VS2;	/* Volatile signed 2byte data type		*/
typedef volatile signed long		VS4;	/* Volatile signed 4byte data type		*/
typedef volatile unsigned char		VU1;	/* Volatile unsigned 1byte data type	*/
typedef volatile unsigned short		VU2;	/* Volatile unsigned 2byte data type	*/
typedef volatile unsigned long		VU4;	/* Volatile unsigned 4byte data type	*/
typedef float						F4;		/* Floating point 4byte date type		*/
typedef double						F8;		/* Floating point 8byte date type		*/
typedef int							BL;		/* Boolean data type					*/

/*==============================================================================================*/
/* Structs																						*/
/*==============================================================================================*/

/*==============================================================================================*/
/* Variables																					*/
/*==============================================================================================*/

/*==============================================================================================*/
/* Constants																					*/
/*==============================================================================================*/

/*==============================================================================================*/
/* Prototypes																					*/
/*==============================================================================================*/

#endif /* #ifndef VP_TYPES_H */
