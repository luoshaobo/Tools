/************************************************************************************************/
/* name         : vp_core.h                                                                     */
/*                                                                                              */
/* description  : Main public interface prototype for VPCORE library.                           */
/*                                                                                              */
/* Copyright(C) DENSO Corporation. All rights reserved.                                         */
/*                                                                                              */
/************************************************************************************************/
/* version      : v1.00  31-03-2014   Wei Z           Initial version.                          */
/*              : v1.10  23-06-2014   Wei Z           Integrated camera calibration feature.    */
/*              : v1.20  26-06-2014   Aji S           Applied coding guideline.                 */
/*              : v1.21  16-09-2014   Aji S           Revised API structure, based on           */
/*                                                    requirements.                             */
/*              : v1.30  03-10-2014   Johnson G       New API support for default map creation  */
/*                                                    based on default camera position.         */
/************************************************************************************************/

#ifndef VP_CORE_H
#define VP_CORE_H

/* Enable C++ compiling. */
#ifdef __cplusplus
extern "C"
{
#endif

/*==============================================================================================*/
/* Includes                                                                                     */
/*==============================================================================================*/

#include "vp_core_typedef.h"

/*==============================================================================================*/
/* Prototypes                                                                                   */
/*==============================================================================================*/

/************************************************************************************************/
/* name         : s4g_VPCore_Enable_DeepCheck                                                   */
/* description  : API enable or disable the deep check error handling mode.                     */
/* parameter    : bl_enable             :[in]  VP_TRUE: Enable, VP_FALSE: Disable.              */
/*              : cfp_error_callback    :[in]  Call back function to be invoked whenever any    */
/*                                             deep check error is observed.                    */
/* return       : Success               :VP_CORE_RESULT_SUCCESS                                 */
/*              : Failure               :Other error codes defined in vp_core_typedef.h         */
/* remarks      :                                                                               */
/************************************************************************************************/
/* version      : v1.00   16-09-2014     DSUK      Initial version.                             */
/************************************************************************************************/
extern S4 s4g_VPCore_Enable_DeepCheck(
          BL                        bl_enable,          /*[in] VP_TRUE: Enable, VP_FALSE: Disable.*/
    const FP_VP_CORE_ERROR_CALLBACK cfp_error_callback  /*[in] Deep check error callback.*/
);

/************************************************************************************************/
/* name         : s4g_VPCore_Calib_Startup                                                      */
/* description  : API to startup VPCORE for Calibration.                                        */
/* parameter    : pcst_calib_param      :[in]  Calibration parameters. Only for calibration.    */
/* return       : Success               :VP_CORE_RESULT_SUCCESS                                 */
/*              : Failure               :Other error codes defined in vp_core_typedef.h         */
/* remarks      :                                                                               */
/************************************************************************************************/
/* version      : v1.00   17-10-2014     DSUK      Initial version.                             */
/************************************************************************************************/
extern S4 s4g_VPCore_Calib_Startup(
    const ST_VP_CORE_CALIB_PARAM    *pcst_calib_param       /* [in]  Calibration parameters. Only for calibration. */
);

/************************************************************************************************/
/* name         : s4g_VPCore_View_Startup                                                       */
/* description  : API to startup VPCORE for View.                                               */
/* parameter    : pcst_view_param       :[in]  View related parameters. Only for view drawings. */
/* return       : Success               :VP_CORE_RESULT_SUCCESS                                 */
/*              : Failure               :Other error codes defined in vp_core_typedef.h         */
/* remarks      :                                                                               */
/************************************************************************************************/
/* version      : v1.00   17-10-2014     DSUK      Initial version.                             */
/************************************************************************************************/
extern S4 s4g_VPCore_View_Startup(
    const ST_VP_CORE_VIEW_PARAM     *pcst_view_param        /* [in]  View related parameters. Only for view drawings. */
);

/************************************************************************************************/
/* name         : s4g_VPCore_UpdateViews                                                        */
/* description  : API to update the views with latest camera image and vehicle state.           */
/* parameter    : en_view_mode          :[in]  Contextual view type.                            */
/*              : pcst_vehicle_info     :[in]  Latest vehicle state.                            */
/*              : u1_hist_transparancy  :[in]  Transparency to be applied to top history        */
/*                                             (0~100%, 0: All visible, 100: Full transparent.) */
/* return       : Success               :VP_CORE_RESULT_SUCCESS                                 */
/*              : Failure               :Other error codes defined in vp_core_typedef.h         */
/* remarks      :                                                                               */
/************************************************************************************************/
/* version      : v1.00   27-02-2014     DSUK      Initial version.                             */
/* version      : v1.10   17-10-2014     DSUK      Modified API parameter structure.            */
/************************************************************************************************/
extern S4 s4g_VPCore_UpdateViews(
          EN_VP_CORE_CONTEXTUAL_VIEW_MODE    en_view_mode,          /* [in]  Contextual view type. */
    const ST_VP_CORE_VEHICLE_INFO           *pcst_vehicle_info,     /* [in]  Latest vehicle state. */
          U1                                 u1_hist_transparancy   /* [in]  Transparency to be applied to top history */
);

/************************************************************************************************/
/* name         : s4g_VPCore_CalibrateCameraInPlant                                             */
/* description  : Function to perform the camera calibration.                                   */
/* parameter    : pst_calib_result      :[out] Calibrated camera position info.                 */
/*              : pst_view_map_obj      :[out] View mas created based on calibrated camera info.*/
/* return       : Success               :VP_CORE_RESULT_SUCCESS                                 */
/*              : Failure               :Other error codes defined in vp_core_typedef.h         */
/* remarks      :                                                                               */
/************************************************************************************************/
/* version      : v1.00   25-05-2014     DSUK      Initial version.                             */
/* version      : v1.10   15-10-2014     DSUK      Updated API parameter structure.             */
/************************************************************************************************/
extern S4 s4g_VPCore_CalibrateCameraInPlant(
    ST_VP_CORE_CAMERA_POS_INFO      *pst_calib_result,      /* [out] Calibrated camera position info. */
    ST_VP_CORE_VIEW_MAP_OBJ         *pst_view_map_obj       /* [out] View mas created based on calibrated camera info. */
);

/************************************************************************************************/
/* name         : s4g_VPCore_CalibrateCameraInDealer                                            */
/* description  : Function to perform the dealer calibration                                    */
/* parameter    : pcst_vehicle_info :[in]  Vehicle Information.                                 */
/*              : u2_vehicle_speed  :[in]  Vehicle Speed.                                       */
/*              : pst_calib_result  :[in]  Calibration Result                                   */
/*              : pst_view_map_obj  :[in]  Map object                                           */
/*              : pen_calib_status  :[in]  Calibration status of the state change               */
/* return       : Success               :VP_CORE_RESULT_SUCCESS                                 */
/*              : Failure               :Other error codes defined in vp_core_typedef.h         */
/* remarks      :                                                                               */
/************************************************************************************************/
/* version      : v1.00   27-02-2014     DSUK       Initial version.                            */
/* version      : v1.30   18-09-2014     DSUK       Dealer Calibration Integration.             */
/************************************************************************************************/
extern S4 s4g_VPCore_CalibrateCameraInDealer(
    const ST_VP_CORE_VEHICLE_INFO      *pcst_vehicle_info,           /* [in]  Vehicle Information. */
          U2                            u2_vehicle_speed,            /* [In]  Vehicle Speed information. */
          ST_VP_CORE_CAMERA_POS_INFO   *pst_calib_result,            /* [out] Structure to hold the calibrated result. */
          ST_VP_CORE_VIEW_MAP_OBJ      *pst_view_map_obj,            /* [out] Map Object for map creation. */
          EN_VP_CORE_CALIB_STATUS      *pen_calib_status             /* [out] Calibration status. */
);

/************************************************************************************************/
/* name         : s4g_VPCore_Create_Default_View_Maps                                           */
/* description  : API to create default map based on default camera setting.                    */
/* parameter    : pcst_cam_pos                  :[in] Camera Position Information.              */
/*              : pcst_std_view_tuning_param    :[in] Standard view tuning parameter            */
/*              : pcst_side_view_tuning_param   :[in] Side view tuning parameter                */
/*              : pcst_vehicle_param            :[in] Vehicle configuration.                    */
/*              : u4_rear_domain_top_view_height:[in]  Top view rear vehicle edge to rear       */
/*                                               display edge [mm] (1000 ~ 1700)                */
/*              : pst_view_map_obj              :[out]New Map Created                           */
/* return       : Success                       :VP_CORE_RESULT_SUCCESS                         */
/*              : Failure                       :Other error codes defined in vp_core_typedef.h */
/* remarks      :                                                                               */
/************************************************************************************************/
/* version      : v1.30   03-10-2014     DSUK      Initial version.                             */
/************************************************************************************************/
extern S4 s4g_VPCore_Create_Default_View_Maps(
   const ST_VP_CORE_CAMERA_POS_INFO    *pcst_cam_pos,                   /* [in]  Camera information                */
   const ST_VP_CORE_VIEW_TUNING_PARAM  *pcst_std_view_tuning_param,     /* [in]  Standard view tuning parameter    */
   const ST_VP_CORE_VIEW_TUNING_PARAM  *pcst_side_view_tuning_param,    /* [in]  Side view tuning parameter        */
   const ST_VP_CORE_VEHICLE_PARAM      *pcst_vehicle_param,             /* [in]  Vehicle configuration parameters. */
         U4                             u4_rear_domain_top_view_height, /* [in]  Top view rear vehicle edge to rear display edge [mm] (1000 ~ 1700) */
         ST_VP_CORE_VIEW_MAP_OBJ       *pst_view_map_obj                /* [out] Map Object                        */
);

/************************************************************************************************/
/* name         : s4g_VPCore_GetVersion                                                         */
/* description  : API to get the latest vpcore version.                                         */
/* parameter    : pst_version           :[in]  Latest VPCore version number.                    */
/* return       : Success               :VP_CORE_RESULT_SUCCESS                                 */
/*              : Failure               :Other error codes defined in vp_core_typedef.h         */
/* remarks      :                                                                               */
/************************************************************************************************/
/* version      : v1.00   27-02-2014     DSUK      Initial version.                             */
/************************************************************************************************/
extern S4 s4g_VPCore_GetVersion(
    ST_VP_CORE_VERSION *pst_version                                   /* Version information of VPCore. */
);

/************************************************************************************************/
/* name         : s4g_VPCore_Reset                                                              */
/* description  : API to reset the VPCORE.                                                      */
/* return       : Success               :VP_CORE_RESULT_SUCCESS                                 */
/*              : Failure               :Other error codes defined in vp_core_typedef.h         */
/* remarks      :                                                                               */
/************************************************************************************************/
/* version      : v1.00   27-02-2014     DSUK      Initial version.                             */
/************************************************************************************************/
extern S4 s4g_VPCore_Reset(
    void
);

/************************************************************************************************/
/* name         : s4g_VPCore_Release                                                            */
/* description  : API to release all resources and shutdown the VPCORE. This requires to call   */
/*                VPCORE startup again to make VPCORE functional.                               */
/* return       : Success               :VP_CORE_RESULT_SUCCESS                                 */
/*              : Failure               :Other error codes defined in vp_core_typedef.h         */
/* remarks      :                                                                               */
/************************************************************************************************/
/* version      : v1.00   27-02-2014     DSUK      Initial version.                             */
/************************************************************************************************/
extern S4 s4g_VPCore_Release(
    void
);

/* Enable C++ compiling. */
#ifdef __cplusplus
}
#endif

#endif /* #ifndef VP_CORE_H */
