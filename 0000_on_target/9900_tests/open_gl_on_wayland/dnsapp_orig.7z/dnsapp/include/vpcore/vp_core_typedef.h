/************************************************************************************************/
/* name         : vp_core_typedef.h                                                             */
/*                                                                                              */
/* description  : Definitions for VPCore public interface.                                      */
/*                                                                                              */
/* Copyright(C) DENSO Corporation. All rights reserved.                                         */
/*                                                                                              */
/************************************************************************************************/
/* version      : v1.00  31-03-2014   Wei Z           Initial version.                          */
/*              : v1.10  23-06-2014   Wei Z           Integrated camera calibration feature.    */
/*              : v1.20  26-06-2014   Aji S           Applied coding guideline.                 */
/*              : v1.21  16-09-2014   Aji S           Revised API structure, based on           */
/*                                                    requirements.                             */
/************************************************************************************************/

#ifndef VP_CORE_TYPEDEF_H
#define VP_CORE_TYPEDEF_H

/*==============================================================================================*/
/* Includes                                                                                     */
/*==============================================================================================*/

#include "vp_types.h"

/*==============================================================================================*/
/* Definitions                                                                                  */
/*==============================================================================================*/

#define VP_CORE_RAM_SIZE_VIEW              (2097152)       /* RAM pool size required for view. */
#define VP_CORE_RAM_SIZE_CALIB             (5242880)       /* RAM pool size required for calibration. */

/* View map data buffer size. */
#define VP_CORE_TOP_VIEW_MAP_SIZE          (723968)        /* 707 KB */
#define VP_CORE_STD_VIEW_MAP_SIZE          (799744)        /* 781 KB */
#define VP_CORE_ZOOM_VIEW_MAP_SIZE         (410624)        /* 401 KB */
#define VP_CORE_SIDE_VIEW_MAP_SIZE         (799744)        /* 781 KB */

/*==============================================================================================*/
/* Enums                                                                                        */
/*==============================================================================================*/

/* Define status codes of all VPCore APIs. */
#define VP_CORE_RESULT_SUCCESS                     (0)
#define VP_CORE_RESULT_INVALID_INPUT               (1)
#define VP_CORE_RESULT_ALREADY_INITIALIZED         (2)
#define VP_CORE_RESULT_NOT_INITIALIZED             (3)
#define VP_CORE_RESULT_ERR_NULL_POINTER            (4)
#define VP_CORE_RESULT_ERR_CPU_MEMORY_NOT_ENOUGH   (5)
#define VP_CORE_RESULT_ERR_INVALID_TEXTURE_MAP     (6)
#define VP_CORE_RESULT_VIEW_NOT_INITIALIZED        (7)
#define VP_CORE_RESULT_CALIBRATION_NOT_INITIALIZED (8)

/* Calibration (factory) */
#define VP_CORE_RESULT_ERR_LOST_VERTEX             (32)
#define VP_CORE_RESULT_ERR_WIDE_VAR_VERTEX         (33)
#define VP_CORE_RESULT_ERR_BIG_DIFF_BOARD          (34)
#define VP_CORE_RESULT_ERR_BIG_DIFF_TPV            (35)

    /* Calibration (dealer) */
#define VP_CORE_RESULT_INITIAL_POSITION_ERROR      (64)
#define VP_CORE_RESULT_CAMERA_POSITION_ERROR       (65)
#define VP_CORE_RESULT_TIME_OUT_ERROR              (66)
#define VP_CORE_RESULT_TOO_FAST_MOVING_ERROR       (67)
#define VP_CORE_RESULT_TOO_BIG_TURNING             (68)

#define VP_CORE_RESULT_VPCOMMON_ERROR              (965)
#define VP_CORE_RESULT_VPOPENGL_ERROR              (1285)

/* Contextual view modes. (Standard / Zoom / Side) */
typedef enum tag_EN_VP_CORE_CONTEXTUAL_VIEW_MODE
{
    VP_CORE_CONTEXTUAL_VIEW_MODE_REAR_VIEW  = 0,
    VP_CORE_CONTEXTUAL_VIEW_MODE_ZOOM_VIEW,
    VP_CORE_CONTEXTUAL_VIEW_MODE_SIDE_VIEW
} EN_VP_CORE_CONTEXTUAL_VIEW_MODE;

/* Define vehicle movement directions. */
typedef enum tag_EN_VP_CORE_DRIVE_DIRECTION
{
    VP_CORE_DRIVE_DIRECTION_INVALID         = 0,
    VP_CORE_DRIVE_DIRECTION_FORWARD,
    VP_CORE_DRIVE_DIRECTION_BACKWARD,
    VP_CORE_DRIVE_DIRECTION_UNDEFINED
} EN_VP_CORE_DRIVE_DIRECTION;

/* Define vehicle gear shift state. */
typedef enum tag_EN_VP_CORE_DRIVE_SHIFT
{
    VP_CORE_DRIVE_SHIFT_NO                  = 0,
    VP_CORE_DRIVE_SHIFT_D,
    VP_CORE_DRIVE_SHIFT_P,
    VP_CORE_DRIVE_SHIFT_N,
    VP_CORE_DRIVE_SHIFT_R,
    VP_CORE_DRIVE_SHIFT_OTHER
} EN_VP_CORE_DRIVE_SHIFT;

/* Define sensor state. */
typedef enum tag_EN_VP_CORE_SENSOR_STATE
{
    VP_CORE_SENSOR_STATE_INVALID            = 0,
    VP_CORE_SENSOR_STATE_VALID
} EN_VP_CORE_SENSOR_STATE;

/* Calibration completion status. */
typedef enum tag_EN_VP_CORE_CALIB_STATUS
{
    VP_CORE_CALIB_STATUS_INIT_PHASE         = 0,
    VP_CORE_CALIB_STATUS_GET_OUT_OF_PARKING_SLOT,
    VP_CORE_CALIB_STATUS_GET_BACK_IN,
    VP_CORE_CALIB_STATUS_CALCULATION,
    VP_CORE_CALIB_STATUS_COMPLETE
} EN_VP_CORE_CALIB_STATUS;

/* View enlarge origin types. */
typedef enum tag_EN_VP_CORE_ENLARGE_ORIGIN
{
    VP_CORE_ENLARGE_ORIGIN_BOTTOM           = 0,
    VP_CORE_ENLARGE_ORIGIN_CENTER,
    VP_CORE_ENLARGE_ORIGIN_TOP
} EN_VP_CORE_ENLARGE_ORIGIN;

/*==============================================================================================*/
/* Structs                                                                                      */
/*==============================================================================================*/

/* Define opengl frame buffer information. */
typedef struct tag_ST_VP_CORE_OPENGL_FRAMEBUFFER_OBJ
{
    U4                                  u4_id;                           /* OpenGL Frame Buffer ID.     */
    S4                                  s4_width;                        /* OpenGL Frame Buffer Width */
    S4                                  s4_height;                       /* OpenGL Frame Buffer Height */
} ST_VP_CORE_OPENGL_FRAMEBUFFER_OBJ;

/* Define a RAM memory block resource */
typedef struct tag_ST_VP_CORE_MEMORY_OBJ
{
    U1                                  *pu1_buffer;                     /* Pointer of RAM area allocated. */
    S4                                  s4_size;                         /* Size of above buffer (in bytes)  */
} ST_VP_CORE_MEMORY_OBJ;

typedef struct tag_ST_VP_CORE_VEHICLE_PARAM
{
    S4                                  s4_vehicle_width;                /* Vehicle overall width [mm] */
    S4                                  s4_wheelbase;                    /* Wheelbase [mm] */
    S4                                  s4_rear_overhang;                /* Real overhang (mm)  */
    S4                                  s4_front_overhang;               /* Front overhang (mm)  */
    U4                                  u4_wheel_circumference;          /* Tire circumference [mm] */
    U4                                  u4_wheel_pulse_number;           /* The number of pulses per a tire circumference */
    U4                                  u4_rear_bumper_edge_height;      /* Bumper area border (Y)  [mm]  */
    U4                                  u4_trailer_hook_length;          /* Trailer hook length [mm] */
    U4                                  u4_trailer_hook_height;          /* Trailer hook height [mm] */
    U4                                  u4_max_linear_steering_angle;    /* the knee point of the steering angle [0.1 deg] */
    U4                                  u4_max_linear_wheel_angle;       /* the knee point of the wheel angle [0.1 deg] */
    U4                                  u4_max_steering_angle;           /* maximum steering angle [0.1 deg] */
    U4                                  u4_max_wheel_angle;              /* maximum wheel angle [0.1 deg] */
} ST_VP_CORE_VEHICLE_PARAM;

/* View map object deinition. */
typedef struct tag_ST_VP_CORE_VIEW_MAP_OBJ
{
    ST_VP_CORE_MEMORY_OBJ               st_std_map;                      /* Standard View */
    ST_VP_CORE_MEMORY_OBJ               st_zoom_map;                     /* Zoom View */
    ST_VP_CORE_MEMORY_OBJ               st_side_map;                     /* Side View */
    ST_VP_CORE_MEMORY_OBJ               st_top_map;                      /* Top View */
} ST_VP_CORE_VIEW_MAP_OBJ;

/* Color pixel definition. */
typedef struct tag_ST_VP_CORE_COLOR_PIXEL
{
    U1                                  u1_r;                            /* Red value.   0 ~ 255 */
    U1                                  u1_g;                            /* Green value. 0 ~ 255 */
    U1                                  u1_b;                            /* Blue value.  0 ~ 255 */
    U1                                  u1_a;                            /* Alpha value. 0 ~ 255 */
} ST_VP_CORE_COLOR_PIXEL;

/* Guideline parameters. */
typedef struct tag_ST_VP_CORE_GDL_PARAM
{
    /* Line color */
    ST_VP_CORE_COLOR_PIXEL              st_distance_line_rear_color_0_3; /* Distance line 0.3m */
    ST_VP_CORE_COLOR_PIXEL              st_distance_line_rear_color_1;   /* Distance line 1m */
    ST_VP_CORE_COLOR_PIXEL              st_distance_line_rear_color_2;   /* Distance line 2m */
    ST_VP_CORE_COLOR_PIXEL              st_trajectory_line_rear_color;   /* Trajectory line */

    /* Line width */
    U1                                  u1_distance_line_width_0_3;      /* Distance line 0.3m [pixel] */
    U1                                  u1_distance_line_width_1;        /* Distance line 1m [pixel] */
    U1                                  u1_distance_line_width_2;        /* Distance line 2m [pixel] */
    U1                                  u1_trajectory_line_width;        /* Trajectory line [pixel] */
} ST_VP_CORE_GDL_PARAM;

/* View settings. */
typedef struct tag_ST_VP_CORE_VIEW_CONTROL_PARAM
{
    U1                                  u1_target_brightness;            /* Target brightness */
    U1                                  u1_brightness_limit_diff;        /* Limit brightness difference */
} ST_VP_CORE_VIEW_CONTROL_PARAM;

/* View tunning settings. */
typedef struct tag_ST_VP_CORE_VIEW_TUNING_PARAM
{
    U1                                  u1_view_vert_enlarge_ratio;      /* Vertical enlargement ratio. */
    U1                                  u1_view_horz_enlarge_ratio;      /* Horizontal enlargement ratio */
    EN_VP_CORE_ENLARGE_ORIGIN           en_view_vert_enlarge_origin;     /* Enlargement origin. */
} ST_VP_CORE_VIEW_TUNING_PARAM;

/* Camera parameters required for VPCore.  */
typedef struct tag_ST_VP_CORE_CAMERA_POS_INFO
{
    F4                                  f4_x;                            /* Camera X position[mm]. */
    F4                                  f4_y;                            /* Camera Y position[mm]. */
    F4                                  f4_z;                            /* Camera Z position[mm]. */
    F4                                  f4_roll;                         /* Roll angle[deg]. */
    F4                                  f4_pitch;                        /* Pitch angle[deg]. */
    F4                                  f4_yaw;                          /* Yaw angle[deg]. */
} ST_VP_CORE_CAMERA_POS_INFO;

/* Define 2D point. */
typedef struct tag_ST_VP_CORE_POINT
{
    S4                                  s4_x;                            /* x co-ordinate of the point. */
    S4                                  s4_y;                            /* y co-ordinate of the point. */
} ST_VP_CORE_POINT;

/* Define rectangular area points. */
typedef struct tag_ST_VP_CORE_RECT_COORDINATES
{
    ST_VP_CORE_POINT                    st_coordinate_rb;                /* Right Bottom Coordinate of Rectangular Area. */
    ST_VP_CORE_POINT                    st_coordinate_rt;                /* Right Top Coordinate of Rectangular Area. */
    ST_VP_CORE_POINT                    st_coordinate_lt;                /* Left Top Coordinate of Rectangular Area. */
    ST_VP_CORE_POINT                    st_coordinate_lb;                /* Left Bottom Coordinate of Rectangular Area. */
} ST_VP_CORE_RECT_COORDINATES;

/* Define target calibration input info. */
typedef struct tag_ST_VP_CORE_PL_CALIB_TARGET_INFO
{
    ST_VP_CORE_RECT_COORDINATES         st_right_pattern;                /* Right region info. */
    ST_VP_CORE_RECT_COORDINATES         st_middle_pattern;               /* Middle region info. */
    ST_VP_CORE_RECT_COORDINATES         st_left_pattern;                 /* Left region info. */
} ST_VP_CORE_PL_CALIB_TARGET_INFO;

/* Startup parameters for View (Drawings). */
typedef struct tag_ST_VP_CORE_VIEW_PARAM
{
    ST_VP_CORE_MEMORY_OBJ               st_memory_pool;                  /* CPU resource: RAM buffer for VPCore's use. */
    ST_VP_CORE_OPENGL_FRAMEBUFFER_OBJ   st_fbo_captured_img;             /* Captured camera image frame buffer. */
    ST_VP_CORE_VIEW_MAP_OBJ             st_view_map_obj;                 /* Memories for View Maps */
    ST_VP_CORE_OPENGL_FRAMEBUFFER_OBJ   st_fbo_top_view;                 /* GPU resource � framebuffer: Result frame buffer for top view. */
    ST_VP_CORE_OPENGL_FRAMEBUFFER_OBJ   st_fbo_contextual_view;          /* Result frame buffer for contextual view. */
    ST_VP_CORE_GDL_PARAM                st_gdl_param;                    /* Guide line design parameters */
    ST_VP_CORE_VIEW_CONTROL_PARAM       st_view_control_param;           /* Parameters to control Top and Contextual views, e.g. Dgamma parameters */
} ST_VP_CORE_VIEW_PARAM;

/* Startup parameters for Camera Calibration. */
typedef struct tag_ST_VP_CORE_CALIB_PARAM
{
    ST_VP_CORE_MEMORY_OBJ               st_memory_pool;                  /* CPU resource: RAM buffer for VPCore's use. */
    ST_VP_CORE_OPENGL_FRAMEBUFFER_OBJ   st_fbo_captured_img;             /* Captured camera image frame buffer. */
    ST_VP_CORE_CAMERA_POS_INFO          st_camera_param_design;          /* The design values of camera parameters. */
    ST_VP_CORE_VEHICLE_PARAM            st_vehicle_param;                /* Static vehicle parameters. */
    ST_VP_CORE_PL_CALIB_TARGET_INFO     st_target_info;                  /* Target board information referred in Calibration (plant) */
    ST_VP_CORE_VIEW_TUNING_PARAM        st_std_view_tuning_parameters;   /* Tuning parameters used for standard view map creation process (calibration) */
    ST_VP_CORE_VIEW_TUNING_PARAM        st_side_view_tuning_parameters;  /* Tuning parameters used for side view map creation process (calibration) */
    U4                                  u4_rear_domain_top_view_height;  /* [mm] (1000 ~ 1700) */
} ST_VP_CORE_CALIB_PARAM;

/* Define vehicle configurations required for VPCore. */
typedef struct tag_ST_VP_CORE_VEHICLE_INFO
{
    U4                                  u4_rl_pulse;                     /* pulse count value rear left */
    U4                                  u4_rr_pulse;                     /* pulse count value rear right */
    U4                                  u4_pulse_timestamp;              /* pulse count received time [ms]7)   */
    S4                                  s4_steer;                        /* steering angle [0.1 deg] */
    U4                                  u4_img_timestamp;                /* image capture time stamp [ms]7)    */
    EN_VP_CORE_DRIVE_DIRECTION          en_direction;                    /* Drive direction */
    EN_VP_CORE_DRIVE_SHIFT              en_shift;                        /* Gear box shift position */
    EN_VP_CORE_SENSOR_STATE             en_rrl_status;                   /* Fault of RRL cues counter */
    EN_VP_CORE_SENSOR_STATE             en_rrr_status;                   /* Fault of RRR cues counter */
    EN_VP_CORE_SENSOR_STATE             en_steer_status;                 /* Fault of steering angle */
} ST_VP_CORE_VEHICLE_INFO;

/* VPCore library version information. */
typedef struct tag_ST_VP_CORE_VERSION
{
    U1                                  u1_version_major;                /* Major version number. */
    U1                                  u1_version_minor;                /* Minor version numbre. */
    U1                                  u1_year;                         /* Last modified date (Year). */
    U1                                  u1_month;                        /* Last modified date (Month). */
    U1                                  u1_date;                         /* Last modified date (Day). */
} ST_VP_CORE_VERSION;

/* Deep check error call back definition. */
typedef void ( *FP_VP_CORE_ERROR_CALLBACK ) (
    S4                                  s4_error_code                    /* Deep check error code. */
);

#endif /* #ifndef VP_CORE_TYPEDEF_H */
