/************************************************************************************************/
/* name         : vpsm_typedef.h																*/
/* description  : VisioPark Wrapper TypedefHeader												*/
/*																								*/
/* Copyright(C) DENSO Corporation																*/
/*																								*/
/************************************************************************************************/
#ifndef VPSM_TYPEDEF_H
#define VPSM_TYPEDEF_H

/*==============================================================================================*/
/* Includes																						*/
/*==============================================================================================*/
#include "vp_types.h"

/*==============================================================================================*/
/* Defines																						*/
/*==============================================================================================*/

/*==============================================================================================*/
/* Macro Functions																				*/
/*==============================================================================================*/

/*==============================================================================================*/
/* Variables																					*/
/*==============================================================================================*/

/*==============================================================================================*/
/* Prototypes																					*/
/*==============================================================================================*/

/*==============================================================================================*/
/* Constants																					*/
/*==============================================================================================*/
/************************************************************************************************/
/* The enforcement result of API.																*/
/* An error level may become the addition in future as soon as internal processing becomes		*/
/* detailed.																					*/
/************************************************************************************************/
typedef enum tag_EN_VP_SM_RESULT {
	VP_SM_RESULT_SUCCESS,				/* Success								*/
	VP_SM_RESULT_ERR_NULL_POINTER,		/* NULL is specified as the parameter	*/
	VP_SM_RESULT_ERR_INVALID_PARAM		/* Parameter values are over the range	*/
} EN_VP_SM_RESULT;

/* Camera mounting location */
typedef enum tag_EN_VP_SM_CAMERA_LOCATION {
	VP_SM_CAMERA_NOT_ON_BOOT,			/* Other than boot	*/
	VP_SM_CAMERA_ON_BOOT				/* Boot				*/
} EN_VP_SM_CAMERA_LOCATION;

/* Distance level of the sonar sensor */
typedef enum tag_EN_VP_SM_OBSTACLE_DIST_ZONE {
	VP_SM_ZONE_1,		/* Zone1		*/
	VP_SM_ZONE_2,		/* Zone2		*/
	VP_SM_ZONE_3,		/* Zone3		*/
	VP_SM_ZONE_4,		/* Zone4		*/
	VP_SM_ZONE_5,		/* Zone5		*/
	VP_SM_ZONE_6,		/* Zone6		*/
	VP_SM_ZONE_7,		/* Zone7		*/
	VP_SM_ZONE_8,		/* Zone8		*/
	VP_SM_ZONE_MISSING	/* Missing		*/
} EN_VP_SM_OBSTACLE_DIST_ZONE;

/* State of the AMSP unit */
typedef enum tag_EN_VP_SM_HMI_REQUEST_FROM_AMSP {
	VP_SM_AMSP_NO_REQUEST,						/* There is no request				*/
	VP_SM_AMSP_CHOICE_OF_DIRECTION_REQUESTED,	/* Request selection				*/
	VP_SM_AMSP_MEASURE_IN_PROGRESS,				/* Under a measurement				*/
	VP_SM_AMSP_AUTOMATIC_STATION_IN_PROGRESS,	/* Under automatic parking			*/
	VP_SM_AMSP_TO_MOVE_FRONT,					/* Under forward movement			*/
	VP_SM_AMSP_TO_MOVE_BACK,					/* Under a backspace				*/
	VP_SM_AMSP_AUTOMATIC_STATION_MOVE_FRONT,	/* Under automatic forward movement	*/
	VP_SM_AMSP_AUTOMATIC_STATION_MOVE_BACK,		/* Under an automatic backspace		*/
	VP_SM_AMSP_END_OF_OPERATE,					/* Operation end					*/
	VP_SM_AMSP_DEACTIVATED						/* Non-operation					*/
} EN_VP_SM_HMI_REQUEST_FROM_AMSP;

/* State of the SCP6 unit */
typedef enum tag_EN_VP_SM_HMI_REQUEST_FROM_SCP6 {
	VP_SM_SCP6_NO_REQUEST,						/* There is no request				*/
	VP_SM_SCP6_REQUEST_DIRECTION_CHOICE,		/* Request selection				*/
	VP_SM_SCP6_MEASURE_IN_PROGRESS,				/* Under a measurement				*/
	VP_SM_SCP6_REQUESTS_TO_ADVANCE,				/* Forward movement request			*/
	VP_SM_SCP6_TRANSITION_REVERSE_GEAR_REQUEST,	/* Reverse gear transition request	*/
	VP_SM_SCP6_AUTOMATIC_PARKING,				/* Under automatic parking			*/
	VP_SM_SCP6_END_OF_MOVING,					/* Action end						*/
	VP_SM_SCP6_DEACTIVATED						/* Non-operation					*/
} EN_VP_SM_HMI_REQUEST_FROM_SCP6;

/* State of the SCP9 unit */
typedef enum tag_EN_VP_SM_HMI_REQUEST_FROM_SCP9 {
	VP_SM_SCP9_NO_REQUEST,						/* There is no request		*/
	VP_SM_SCP9_REQUEST_DIRECTION_CHOICE,		/* Request selection		*/
	VP_SM_SCP9_AUTOMATIC_PARKING_EXIT,			/* Automatic parking end	*/
	VP_SM_SCP9_END_OF_OPERATE,					/* Operation end			*/
	VP_SM_SCP9_DEACTIVATED						/* Non-operation			*/
} EN_VP_SM_HMI_REQUEST_FROM_SCP9;

/* User request */
typedef enum tag_EN_VP_SM_PUSH_REQUEST {
	VP_SM_NO_PUSH_REQUESTED,					/* not requested	*/
	VP_SM_PUSH_REQUESTED						/* requested		*/
} EN_VP_SM_PUSH_REQUEST;

/* Boot state */
typedef enum tag_EN_VP_SM_BOOT_STATUS {
	VP_SM_BOOT_CLOSED,		/* close	*/
	VP_SM_BOOT_OPEN			/* open		*/
} EN_VP_SM_BOOT_STATUS;

/* Engine state */
typedef enum tag_EN_VP_SM_ENGINE_STATUS {
	VP_SM_ENGINE_NOT_RUNNING,			/* not running				*/
	VP_SM_ENGINE_STARTING,				/* starting					*/
	VP_SM_ENGINE_RUNNING,				/* running					*/
	VP_SM_ENGINE_STOPPED_IN_STOP_PHASE	/* stopped in stop phase	*/
} EN_VP_SM_ENGINE_STATUS;

/* Reverse gear state */
typedef enum tag_EN_VP_SM_REVERSE_GEAR_STATUS {
	VP_SM_REVERSE_NOT_ENGAGED,			/* not engaged	*/
	VP_SM_REVERSE_ENGAGED,				/* engaged		*/
	VP_SM_REVERSE_MISSING				/* missing 		*/
} EN_VP_SM_REVERSE_GEAR_STATUS;

/* Key position state */
typedef enum tag_EN_VP_SM_KEY_POSITION {
	VP_SM_KEY_STOP,						/* stop					*/
	VP_SM_KEY_CONTACT,					/* contact				*/
	VP_SM_KEY_DEM,						/* dem					*/
	VP_SM_KEY_FREE						/* free(N/A for VP1)	*/
} EN_VP_SM_KEY_POSITION;

/* Vehicle established state */
typedef enum tag_EN_VP_SM_VEHICLE_CONFIG {
	VP_SM_VEHICLE_FITTING,				/* fitting				*/
	VP_SM_VEHICLE_PLANT,				/* plant				*/
	VP_SM_VEHICLE_CHECK,				/* check				*/
	VP_SM_VEHICLE_STORAGE_TRANSPORT,	/* storage transport	*/
	VP_SM_VEHICLE_CLIENT,				/* client				*/
	VP_SM_VEHICLE_SHOW_ROOM,			/* show room			*/
	VP_SM_VEHICLE_APV,					/* apv					*/
	VP_SM_VEHICLE_INVALID				/* invalid				*/
} EN_VP_SM_VEHICLE_CONFIG;

/* Trailer connection state */
typedef enum tag_EN_VP_SM_TRAILER_PRESENT_STATUS {
	VP_SM_NO_TRAILER,		/* no trailer		*/
	VP_SM_TRAILER_PRESENT	/* trailer present	*/
} EN_VP_SM_TRAILER_PRESENT_STATUS;

/* Gearbox type */
typedef enum tag_EN_VP_SM_GEAR_BOX_TYPE {
	VP_SM_AGB_MODE,		/* AGB	*/
	VP_SM_MGB_MODE,		/* MGB	*/
	VP_SM_PMGB_MODE,	/* PMGB	*/
	VP_SM_DCT_MODE		/* DCT	*/
} EN_VP_SM_GEAR_BOX_TYPE;

/*Drawing request */
typedef enum tag_EN_VP_SM_VIEW_REQUEST {
	VP_SM_VIEW_NO_REQUEST,			/* no request	*/
	VP_SM_VIEW_REQUEST_AUTO,		/* auto			*/
	VP_SM_VIEW_REQUEST_STANDARD,	/* standard		*/
	VP_SM_VIEW_REQUEST_ZOOM,		/* zoom			*/
	VP_SM_VIEW_REQUEST_SIDE			/* side			*/
} EN_VP_SM_VIEW_REQUEST;

/* Sonar state */
typedef enum tag_EN_VP_SM_ULTRASONIC_STATUS {
	VP_SM_ULTRASONIC_NOT_DEFINED,			/* not defined			*/
	VP_SM_ULTRASONIC_FAULT,					/* fault				*/
	VP_SM_ULTRASONIC_DRIVER_INHIBITION,		/* driver inhibition	*/
	VP_SM_ULTRASONIC_TRAILER_INHIBITION,	/* trailer inhibition	*/
	VP_SM_ULTRASONIC_ACTIVE,				/* active				*/
	VP_SM_ULTRASONIC_WAIT,					/* wait					*/
	VP_SM_ULTRASONIC_OUT_OF_SERVICE			/* out of service		*/
} EN_VP_SM_ULTRASONIC_STATUS;

/* Sonar drawing request */
typedef enum tag_EN_VP_SM_ULTRASONIC_DISP_REQUEST {
	VP_SM_NO_DISPLAY_REQUEST,		/* no display request	*/
	VP_SM_DISPLAY_REQUEST			/* display request		*/
} EN_VP_SM_ULTRASONIC_DISP_REQUEST;

/* Param Status */
typedef enum tag_EN_VP_SM_PARAM_STATUS {
	VP_SM_PARAM_STATUS_ABNORMAL,	/* Param status abnormal	*/
	VP_SM_PARAM_STATUS_NORMAL		/* Param status normal		*/
} EN_VP_SM_PARAM_STATUS;

/* VisioPark operation state */
typedef enum tag_EN_VP_SM_ACTIVE_VPARK {
	VP_SM_VPARK_INACTIVE,	/* inactive	*/
	VP_SM_VPARK_ACTIVE		/* active	*/
} EN_VP_SM_ACTIVE_VPARK;

/* VisioPark automatic state */
typedef enum tag_EN_VP_SM_VPARK_AUTO {
	VP_SM_VPARK_AUTO_INACTIVE,	/* inactive	*/
	VP_SM_VPARK_AUTO_ACTIVE		/* active	*/
} EN_VP_SM_VIEW_VPARK_AUTO;

/* VisioPark drawing state */
typedef enum tag_EN_VP_SM_VIEW_VPARK {
	VP_SM_DISPLAY_VIEW_NONE,			/* none							*/
	VP_SM_DISPLAY_VIEW_REAR_STANDARD,	/* rear standard				*/
	VP_SM_DISPLAY_VIEW_REAR_ZOOM,		/* rear zoom					*/
	VP_SM_DISPLAY_VIEW_REAR_SIDE,		/* rear side					*/
	VP_SM_DISPLAY_VIEW_FRONT_STANDARD,	/* front standard(N/A for VP1)	*/
	VP_SM_DISPLAY_VIEW_FRONT_ZOOM,		/* front zoom(N/A for VP1)		*/
	VP_SM_DISPLAY_VIEW_FRONT_SIDE		/* front side(N/A for VP1)		*/
} EN_VP_SM_VIEW_VPARK;

/* History clear request information */
typedef enum tag_EN_VP_SM_HISTORY_CLEAR_REQUEST {
	VP_SM_HISTORY_NO_REQUEST,			/* History no request		*/
	VP_SM_HISTORY_REQUEST_CLEAR			/* History request clear	*/
} EN_VP_SM_HISTORY_CLEAR_REQUEST;

/* History information computing state */
typedef enum tag_EN_VP_SM_COMPUTING_STATUS {
	VP_SM_COMPUTING_NO_REQUEST,	/* Not computing	*/
	VP_SM_COMPUTING_REQUEST		/* Computing		*/
} EN_VP_SM_COMPUTING_STATUS;

/*==============================================================================================*/
/* Structs																						*/
/*==============================================================================================*/
/************************************************************************************************/
/* Configure Parameters																			*/
/* The addition of the member may occur in future as soon as internal processing becomes		*/
/* detailed.																					*/
/************************************************************************************************/
typedef struct tag_ST_VP_SM_CONFIG_PARAMETERS {
	U2								u2_max_speed_for_display_off;								/* max speed for display off								*/
	U2								u2_max_speed_for_vpark_off;									/* max speed for vpark off									*/
	U2								u2_hysteresis_speed_for_vpark_display_off;					/* hysteresis speed for vpark display off					*/
	U4								u4_delay_time_for_vpark_off_after_display_off;				/* delay time for vpark off after display off				*/
	U4								u4_delay_time_for_vpark_off_after_reverse_disengaged;		/* delay time for vpark off after reverse disengaged		*/
	U4								u4_delay_time_for_vpark_on_after_reverse_engaged;			/* delay time for vpark on after reverse engaged			*/
	U4								u4_delay_time_for_zoomedview_after_obstacle_detected;		/* delay time for zoomedview after obstacle detected		*/
	U4								u4_delay_time_for_standardview_after_obstacle_disappeared;	/* delay time for standardview after obstacle disappeared	*/
	U4								u4_delay_time_for_engine_on_after_engine_stall;				/* Delay time from engine stall to engine start again		*/
	U4								u4_delay_time_for_not_computing_after_reverse_disengaged;	/* Delay time for not computing after reverse disengaged	*/
	EN_VP_SM_CAMERA_LOCATION		en_camera_location;											/* camera location											*/
	EN_VP_SM_OBSTACLE_DIST_ZONE		en_rear_side_dist_for_zoomedview;							/* rear side dist for zoomedview							*/
	EN_VP_SM_OBSTACLE_DIST_ZONE		en_rear_mid_dist_for_zoomedview;							/* rear mid dist for zoomedview								*/
	EN_VP_SM_OBSTACLE_DIST_ZONE		en_rear_side_dist_for_standardview;							/* rear side dist for standardview							*/
	EN_VP_SM_OBSTACLE_DIST_ZONE		en_rear_mid_dist_for_standardview;							/* rear mid dist for standardview							*/
} ST_VP_SM_CONFIG_PARAMETERS;

/************************************************************************************************/
/* State Machine Input Informations																*/
/* The addition of the member may occur in future as soon as internal processing becomes		*/
/* detailed.																					*/
/************************************************************************************************/
typedef struct tag_ST_VP_SM_INPUT_INFO {
	U2									u2_vehicle_speed;				/* vehicle speed				*/
	EN_VP_SM_HMI_REQUEST_FROM_AMSP		en_hmi_request_from_amsp;		/* hmi request from amsp		*/
	EN_VP_SM_HMI_REQUEST_FROM_SCP6		en_hmi_request_from_scp6;		/* hmi request from scp6		*/
	EN_VP_SM_HMI_REQUEST_FROM_SCP9		en_hmi_request_from_scp9;		/* hmi request from scp9		*/
	EN_VP_SM_PUSH_REQUEST				en_push_request;				/* push request					*/
	EN_VP_SM_BOOT_STATUS				en_boot_status;					/* boot status					*/
	EN_VP_SM_ENGINE_STATUS				en_engine_status;				/* engine status				*/
	EN_VP_SM_REVERSE_GEAR_STATUS		en_reverse_gear_status;			/* reverse gear status			*/
	EN_VP_SM_KEY_POSITION				en_key_position;				/* key position					*/
	EN_VP_SM_VEHICLE_CONFIG				en_vehicle_config;				/* vehicle config				*/
	EN_VP_SM_TRAILER_PRESENT_STATUS		en_trailer_present_status;		/* trailer present status		*/
	EN_VP_SM_GEAR_BOX_TYPE				en_gear_box_type;				/* gear box type				*/
	EN_VP_SM_VIEW_REQUEST				en_view_request;				/* view request					*/
	EN_VP_SM_ULTRASONIC_STATUS			en_rear_ultrasonic_status;		/* rear ultrasonic status		*/
	EN_VP_SM_ULTRASONIC_DISP_REQUEST	en_ultrasonic_display_request;	/* ultrasonic display request	*/
	EN_VP_SM_OBSTACLE_DIST_ZONE			en_rear_right_obstacle_dist;	/* rear right obstacle dist		*/
	EN_VP_SM_OBSTACLE_DIST_ZONE			en_rear_middle_obstacle_dist;	/* rear middle obstacle dist	*/
	EN_VP_SM_OBSTACLE_DIST_ZONE			en_rear_left_obstacle_dist;		/* rear left obstacle dist		*/
	EN_VP_SM_PARAM_STATUS				en_param_status_vehicle_speed;	/* param status vehicle speed	*/
} ST_VP_SM_INPUT_INFO;

/* State Machine Output Informations */
typedef struct tag_ST_VP_SM_OUTPUT_INFO {
	EN_VP_SM_ACTIVE_VPARK			en_active_vpark;			/* active vpark							*/
	EN_VP_SM_VIEW_VPARK_AUTO		en_view_vpark_auto;			/* view vpark auto						*/
	EN_VP_SM_VIEW_VPARK 			en_view_vpark;				/* view vpark							*/
	EN_VP_SM_HISTORY_CLEAR_REQUEST	en_history_clear_request;	/* history clear request				*/
	EN_VP_SM_COMPUTING_STATUS		en_computing_status;		/* history information computing state	*/
} ST_VP_SM_OUTPUT_INFO;

/* State Machine Version Informations */
typedef struct tag_ST_VP_SM_VERSION {
	U1	u1_version_major;	/* major of version	*/
	U1	u1_version_minor;	/* minor of version	*/
	U1	u1_year;			/* build of year	*/
	U1	u1_month;			/* build of month	*/
	U1	u1_date;			/* build of date	*/
} ST_VP_SM_VERSION;

#endif /* #ifndef VPSM_TYPEDEF_H */

