/************************************************************************************************/
/* name         : vpsm.h                                                                        */
/*                                                                                              */
/* description  : Module: Visiopark State Machine Library for VP1.                              */
/*                Public interface prototype for state machine module.                          */
/*                                                                                              */
/* Copyright(C) DENSO Corporation                                                               */
/*                                                                                              */
/************************************************************************************************/
/* version      : v1.00  28-05-2014   Wei Z                  Initial implementation.            */
/*              : v1.10  14-08-2014   Aji S                  Applied coding guideline.          */
/************************************************************************************************/

#ifndef VPSM_H
#define VPSM_H

/*==============================================================================================*/
/* Includes                                                                                     */
/*==============================================================================================*/

#include "vpsm_typedef.h"

/*==============================================================================================*/
/* Prototypes                                                                                   */
/*==============================================================================================*/

/************************************************************************************************/
/* name         : eng_VPSM_Initialise                                                           */
/* description  : Function to initialize the state machine library                              */
/* parameter    : pcst_config_parameters:[in] Input params to configure / initialize.           */
/* return       : Success               :VP_SM_RESULT_SUCCESS                                   */
/*              : Failure               :Other error codes defined in EN_VP_SM_RESULT           */
/* remarks      : This function should be called at first before calling any other VPSM APIs.   */
/************************************************************************************************/
/* version      : v1.00  25-06-2014   Wei Z            Initial version.                         */
/*              : v1.10  14-08-2014   Aji S            Applied coding guideline.                */
/************************************************************************************************/
extern EN_VP_SM_RESULT eng_VPSM_Initialise(
    const ST_VP_SM_CONFIG_PARAMETERS *pcst_config_parameters
);

/************************************************************************************************/
/* name         : eng_VPSM_Step                                                                 */
/* description  : Function to be continiously called with latest vehicle state.                 */
/* parameter    : pcst_input_info       :[in]  Latest input state.                              */
/*              : pst_output_info       :[out] Latest state machine result.                     */
/* return       : Success               :VP_SM_RESULT_SUCCESS                                   */
/*              : Failure               :Other error codes defined in EN_VP_SM_RESULT           */
/* remarks      : This function should be called at fixed regular period of intervals.          */
/************************************************************************************************/
/* version      : v1.00  25-06-2014   Wei Z            Initial version.                         */
/*              : v1.10  14-08-2014   Aji S            Applied coding guideline.                */
/************************************************************************************************/
extern EN_VP_SM_RESULT eng_VPSM_Step(
    const ST_VP_SM_INPUT_INFO  *pcst_input_info,
          ST_VP_SM_OUTPUT_INFO *pst_output_info
);

/************************************************************************************************/
/* name         : eng_VPSM_GetStatus                                                            */
/* description  : Function to get the latest ouput state from state machine module.             */
/* parameter    : pst_output_info       :[out] Latest state machine result.                     */
/* return       : Success               :VP_SM_RESULT_SUCCESS                                   */
/*              : Failure               :Other error codes defined in EN_VP_SM_RESULT           */
/* remarks      :                                                                               */
/************************************************************************************************/
/* version      : v1.00  25-06-2014   Wei Z            Initial version.                         */
/*              : v1.10  14-08-2014   Aji S            Applied coding guideline.                */
/************************************************************************************************/
extern EN_VP_SM_RESULT eng_VPSM_GetStatus(
    ST_VP_SM_OUTPUT_INFO *pst_output_info
);

/************************************************************************************************/
/* name         : eng_VPSM_GetVersion                                                           */
/* description  : Function to get version of State Machine Software library.                    */
/* parameter    : pst_version           :[out] State machine software library version.          */
/* return       : Success               :VP_SM_RESULT_SUCCESS                                   */
/*              : Failure               :Other error codes defined in EN_VP_SM_RESULT           */
/* remarks      :                                                                               */
/************************************************************************************************/
/* version      : v1.00  25-06-2014   Wei Z            Initial version.                         */
/*              : v1.10  14-08-2014   Aji S            Applied coding guideline.                */
/************************************************************************************************/
extern EN_VP_SM_RESULT eng_VPSM_GetVersion(
    ST_VP_SM_VERSION *pst_version
);

#endif /* VPSM_H */
