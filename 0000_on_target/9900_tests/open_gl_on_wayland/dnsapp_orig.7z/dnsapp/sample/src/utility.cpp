/************************************************************************************************/
/* Name         : utility.cpp                                                                   */
/* Content      : Utility class to implement the local function which needs to be used by sample*/
/*              : application.                                                                  */
/* Note         : Sample application for demonstrating the VP1 Software                         */
/* Version      : V1.00  31-07-2014   Johnson George           Initial version.                 */
/************************************************************************************************/

#include "utility.h"

utility::utility()
{
    /* Constructor */
}

/************************************************************************************************/
/* Name         : GetFileName                                                                   */
/* Function     : This function returns the image file name                                     */
/* Argument     : Prefix of filename                                                            */
/*              : Index                                                                         */
/*              : Char pointer in which the filename will be returned                           */
/* Return values: Status of operation                                                           */
/* Note         :                                                                               */
/* remarks      :                                                                               */
/* version      : V1.00   30-06-2014     1.0 OpenGL Utility Class Initial version.              */
/************************************************************************************************/
EN_SAMPLEAPP_ERRORCODE utility::GetFileName(S1 *u1_prefix, U4 u4_index, S1 *pFileName)
{
    EN_SAMPLEAPP_ERRORCODE  ent_utlity_return = EN_SAMPLEAPP_STATUS_SUCCESS;

    if ((u1_prefix == NULL) || (u4_index > 999999 )) {
        ent_utlity_return = EN_SAMPLEAPP_STATUS_INVALID_PARAM;
    } else {/* N.O.P */}
    if(EN_SAMPLEAPP_STATUS_SUCCESS == ent_utlity_return) {
        if ((strlen((char*)u1_prefix)+ MAX_INDEX_SIZE_SUPPORTED + BMP_FORMAT_INDENTIFIER + 1) > MAX_FILE_NAME_SIZE)
            ent_utlity_return = EN_SAMPLEAPP_STATUS_INVALID_PARAM;
        else
            sprintf((char*)pFileName,"%s%06lu%s", u1_prefix,u4_index,".bmp");
    } else {/* N.O.P */}
    return ent_utlity_return;
}

/************************************************************************************************/
/* Name         : LoadBitmap_24RGB                                                              */
/* Function     : This function loads the content of the bitmap into a char buffer              */
/* Argument     : FileName                                                                      */
/*              : Width of BMP Image                                                            */
/*              : Height of BMP Image                                                           */
/*              : Datasize of the BMP Image                                                     */
/*              : Output Buffer to return the BMP content                                       */
/* Return values: Status of operation                                                           */
/* Note         :                                                                               */
/* remarks      :                                                                               */
/* version      : V1.00   30-06-2014     1.0 OpenGL Utility Class Initial version.              */
/************************************************************************************************/
EN_SAMPLEAPP_ERRORCODE utility::LoadBitmap_24RGB(const S1 *u1_fileName, S4 s4_width, S4 s4_height, S4 s4_dataSize, U1 *u1_out)
{
    FILE *fp = NULL;
    U1 buf[4] = {0};
    S4 s4t_offset = 0;
    S4 s4t_width = s4_width;
    S4 s4t_height = s4_height;
    S4 s4t_bitCount = 24;
    U4 u4t_line = 0;
    U1 *data = NULL;
    U4 u4t_count1 = 0, u4t_count2 = 0;
    const BGR *src = NULL;
    RGB *dst = NULL;

    EN_SAMPLEAPP_ERRORCODE  ent_utlity_return = EN_SAMPLEAPP_STATUS_SUCCESS;


    if ((u1_fileName == NULL) || (s4_width <= 0) || (s4_height <= 0) || (u1_out == NULL) || (s4_dataSize <= 0)) {
        ent_utlity_return = EN_SAMPLEAPP_STATUS_INVALID_PARAM;
    } else {/* N.O.P */}
    if(EN_SAMPLEAPP_STATUS_SUCCESS == ent_utlity_return) {
        fp = fopen((char*)u1_fileName, "rb");
    if (fp == NULL) {
            ent_utlity_return = EN_SAMPLEAPP_STATUS_FILE_OPEN_ERROR;
        } else {
    fseek(fp, 10, 0);
    fread(buf, 4, 1, fp);
    s4t_offset = buf[0]+buf[1]*256+buf[2]*256*256+buf[3]*256*256*256;
    fseek(fp, s4t_offset, 0);

    u4t_line = (s4t_width * s4t_bitCount) / 8;
    if ((u4t_line % 4) != 0) {
        u4t_line = ((u4t_line / 4) + 1) * 4;
            }else {/* N.O.P */}

    data = new U1 [u4t_line*s4t_height];
    fread(data, u4t_line*s4t_height, 1, fp);
    src = (const BGR *)data;
    dst = (RGB *)u1_out;

    dst += (s4t_height - 1) * s4t_width;
    u4t_count1 = s4t_height & ~3;

    do {
        u4t_count2 = s4t_width & ~3;
        do {
                dst->r = src->r;
                dst->g = src->g;
                dst->b = src->b;
                src++;
                dst++;
        } while (--u4t_count2);
        dst -= 2 * s4t_width;
    } while (--u4t_count1);

    fclose(fp);
    if (data != NULL) {
        delete [] data;
        data = NULL;
            } else {/* N.O.P */}
        }
    } else {/* N.O.P */}
    return ent_utlity_return;
}

EN_SAMPLEAPP_ERRORCODE utility::LoadMapFromFile(const char *pFileName,U1 *u1_mapdata,S4 s4_size)
{
    FILE *fp = NULL;
    S4 s4t_read_count = 0;
    U1 *pu1t_map_buff = NULL;

    EN_SAMPLEAPP_ERRORCODE  ent_utlity_return = EN_SAMPLEAPP_STATUS_SUCCESS;

    fp = fopen(pFileName,"rb");
    if(fp == NULL)
    {
        printf("utility::LoadMapFromFile::Failed to open the file\n");
        ent_utlity_return = EN_SAMPLEAPP_STATUS_FILE_OPEN_ERROR;
    }
    else
    {
        if(u1_mapdata != NULL)
        {
            pu1t_map_buff = u1_mapdata;
            s4t_read_count = fread(pu1t_map_buff,s4_size,1,fp);
            if(s4t_read_count != 1)
            {
                printf("utility::LoadMapFromFile::Failed to read from file\n");
                ent_utlity_return = EN_SAMPLEAPP_STATUS_MAP_LOAD_FAILED;
            }
        }
        else
        {
            ent_utlity_return = EN_SAMPLEAPP_STATUS_MAP_LOAD_FAILED;
        }
    }

    if(fp != NULL)
    {
        fclose(fp);
    } else {/* N.O.P */}

    return ent_utlity_return;
}


EN_SAMPLEAPP_ERRORCODE utility::StoreMapToFile(const char *pFileName,const U1 *u1_mapdata,S4 s4_size)
{
    FILE *fp = NULL;
    S4 s4t_write_count = 0;
    EN_SAMPLEAPP_ERRORCODE  ent_utlity_return = EN_SAMPLEAPP_STATUS_SUCCESS;

    fp = fopen(pFileName,"wb");
    if(fp == NULL)
    {
        printf("utility::StoreMap::Failed to open the file\n");
        ent_utlity_return = EN_SAMPLEAPP_STATUS_FILE_OPEN_ERROR;
    }
    else
    {
        s4t_write_count = fwrite(u1_mapdata,s4_size,1,fp);
        if(s4t_write_count != 1)
        {
            printf("utility::StoreMap::Failed to write to the file\n");
            ent_utlity_return = EN_SAMPLEAPP_STATUS_MAP_STORE_FAILED;
        } else {/* N.O.P */}
    }
    if(fp != NULL)
    {
        fclose(fp);
    } else {/* N.O.P */}
    return ent_utlity_return;
}

/************************************************************************************************/
/* Name         : DisplayErrorMessage                                                           */
/* Function     : This function will print the error code                                       */
/* Argument     : Enumerated Error Codde                                                        */
/* Return values: None                                                                          */
/* Note         :                                                                               */
/* remarks      :                                                                               */
/* version      : V1.00   30-06-2014     1.0 OpenGL Utility Class Initial version.              */
/************************************************************************************************/
void utility::DisplayErrorMessage(EN_SAMPLEAPP_ERRORCODE en_sampleapp_err)
{
    switch(en_sampleapp_err)
    {
        case EN_SAMPLEAPP_STATUS_SUCCESS:
            printf("Sample Application Status OK\n");
            break;
        case EN_SAMPLEAPP_STATUS_FAILED:
            printf("Sample Application Status Failed\n");
            break;
        case EN_SAMPLEAPP_STATUS_FILE_OPEN_ERROR:
            printf("Sample Application Status File Open Error\n");
            break;
        case EN_SAMPLEAPP_STATUS_INVALID_PARAM:
            printf("Sample Application Status Invalid Parameter\n");
            break;
        case EN_SAMPLEAPP_STATUS_VPCORE_STARTUP_FAILED:
            printf("Sample Application Status VPCORE Startup API Failed \n");
            break;
        case EN_SAMPLEAPP_STATUS_VPCORE_UPDATE_FAILED:
            printf("Sample Application Status VPCORE Update API Failed \n");
            break;
        case EN_SAMPLEAPP_STATUS_VPCORE_RESET_FAILED:
            printf("Sample Application Status VPCORE Reset API FAILED \n");
            break;
        case EN_SAMPLEAPP_STATUS_VPCORE_RELEASE_FAILED:
            printf("Sample Application Status VPCORE RELEASE API FAILED\n");
            break;
        case EN_SAMPLEAPP_STATUS_OPENGL_INITIALIZATION_FAILED:
            printf("Sample Application Status OPENGL INITIALIZATION FAILED \n");
            break;
        case EN_SAMPLEAPP_STATUS_VPCORE_FACTORY_CALIB_FAILED:
            printf("Sample Application Factory Calibration FAILED \n");
            break;
        case EN_SAMPLEAPP_STATUS_VPCORE_DEALER_CALIB_FAILED:
            printf("Sample Application Dealer Calibration FAILED \n");
            break;
        case EN_SAMPLEAPP_STATUS_MAP_LOAD_FAILED:
            printf("Sample Application Map loading FAILED \n");
            break;
        case EN_SAMPLEAPP_STATUS_MAP_STORE_FAILED:
            printf("Sample Application Map Storing FAILED \n");
            break;
        case EN_SAMPLEAPP_CALIBRATION_NOT_INITIALIZED:
            printf("Sample Application calibration initialization not performed \n");
            break;
        case EN_SAMPLEAPP_VIEW_NOT_INITIALIZED:
            printf("Sample Application view initialization not performed \n");
            break;
        case EN_SAMPLEAPP_DEFAULT_MAP_CREATION_FAILED:
            printf("Sample Application default view map creation FAILED \n");
            break;
        default:
            printf("Invalid Error\n");
    }
    return;
}
