#ifndef OPENGLDEFS_H
#define OPENGLDEFS_H

/************************************************************************************************/
/* Name         : opengldefs.h                                                                  */
/* Content      : Macro defination for the openGL functions                                     */
/* Note         :                                                                               */
/* Version      : V1.00  31-07-2014   Johnson George           Initial version.                 */
/************************************************************************************************/

typedef struct st_color {
    U1 B;
    U1 G;
    U1 R;
}ST_COLOR;

typedef struct st_color32 {
    U1 R;
    U1 G;
    U1 B;
    U1 A;
}ST_COLOR32;

const EGLint configAttribs[] =
{
  EGL_RED_SIZE,        8,
  EGL_GREEN_SIZE,      8,
  EGL_BLUE_SIZE,       8,
  EGL_ALPHA_SIZE,      8,
  EGL_DEPTH_SIZE,      0,
  EGL_STENCIL_SIZE,    0,
  EGL_SAMPLE_BUFFERS,  0,
  EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT,
  EGL_NONE
};

const EGLint contextAttribs[] =
{
  EGL_CONTEXT_CLIENT_VERSION, 2,
  EGL_NONE
};

typedef struct {
    GLfloat m[4][4];
} EXT_GL_MATRIX;

typedef enum {
    APP_GL_TOPVIEW = 0,
    APP_GL_CUSTOMVIEW,
    APP_GL_CAM_IMAGE
} AppGlViewType;

enum {
    APP_GL_SHDPG_TEX = 0,	/* Texture */
    APP_GL_SHDPG_CLR,		/* Color   */

    APP_GL_SHDPG_NUM
};

/* Index of the variable of the shader program */
typedef struct {
    S4 u_matrix;
    S4 u_pointsize;
    S4 s_texture;
    S4 a_texCoord;
    S4 a_position;
    S4 a_color;
} APP_GL_PG_LOCATION;

#ifndef FALSE
#define FALSE               0
#endif

#ifndef TRUE
#define TRUE                1
#endif

#define OUT_MAX_SIZE_X      732
#define OUT_MAX_SIZE_Y      390
#define FORM_DISP_WIDTH		OUT_MAX_SIZE_X
#define FORM_DISP_HEIGHT	OUT_MAX_SIZE_Y

#define DISP_WIDTH          732
#define DISP_HEIGHT         390
#define TOPVIEW_WIDTH       208
#define TOPVIEW_HEIGHT      DISP_HEIGHT
#define TOPVIEW_L		    0
#define TOPVIEW_T		    0
#define TOPVIEW_R           (TOPVIEW_L + TOPVIEW_WIDTH)
#define TOPVIEW_B           (TOPVIEW_T + TOPVIEW_HEIGHT)

#define CUSTOMVIEW_WIDTH	512
#define CUSTOMVIEW_HEIGHT	DISP_HEIGHT
#define CUSTOMVIEW_L		(TOPVIEW_WIDTH)
#define CUSTOMVIEW_T		0
#define CUSTOMVIEW_R		(CUSTOMVIEW_L + CUSTOMVIEW_WIDTH)
#define CUSTOMVIEW_B		(CUSTOMVIEW_T + CUSTOMVIEW_HEIGHT)

#define TOPVIEW_DOTPITCH_X	20.0
#define TOPVIEW_DOTPITCH_Y	TOPVIEW_DOTPITCH_X
#define DRAWARC_SEGNUM_MAX	4

#define CAM_IMG_WIDTH       (640)
#define CAM_IMG_HEIGHT      (480)

#define EXT_GL_MATRIX_ITEM(mat, x, y)	((mat)->m[(y)][(x)])

#endif // OPENGLDEFS_H
