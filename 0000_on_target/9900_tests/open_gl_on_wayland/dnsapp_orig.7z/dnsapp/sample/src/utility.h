#ifndef UTILITY_H
#define UTILITY_H

/************************************************************************************************/
/* Name         : utility.h                                                                     */
/* Content      : Utility class to implement the local function which needs to be used by sample*/
/*              : application.                                                                  */
/* Note         :                                                                               */
/* Version      : V1.00  31-07-2014   Johnson George           Initial version.                 */
/************************************************************************************************/

#include <string.h>
#include <stdio.h>
#include "vp_types.h"

#define MAX_FILE_NAME_SIZE          255
#define MAX_INDEX_SIZE_SUPPORTED    6
#define BMP_FORMAT_INDENTIFIER      4

typedef enum tag_EN_SAMPLEAPP_ERRORCODE
{
    EN_SAMPLEAPP_STATUS_SUCCESS = 0,
    EN_SAMPLEAPP_STATUS_FAILED,
    EN_SAMPLEAPP_STATUS_FILE_OPEN_ERROR,
    EN_SAMPLEAPP_STATUS_INVALID_PARAM,
    EN_SAMPLEAPP_STATUS_VPCORE_STARTUP_FAILED,
    EN_SAMPLEAPP_STATUS_VPCORE_UPDATE_FAILED,
    EN_SAMPLEAPP_STATUS_VPCORE_DEALER_CALIB_FAILED,
    EN_SAMPLEAPP_STATUS_VPCORE_FACTORY_CALIB_FAILED,
    EN_SAMPLEAPP_STATUS_VPCORE_RESET_FAILED,
    EN_SAMPLEAPP_STATUS_VPCORE_RELEASE_FAILED,
    EN_SAMPLEAPP_STATUS_OPENGL_INITIALIZATION_FAILED,
    EN_SAMPLEAPP_STATUS_MAP_LOAD_FAILED,
    EN_SAMPLEAPP_STATUS_MAP_STORE_FAILED,
    EN_SAMPLEAPP_CALIBRATION_NOT_INITIALIZED,
    EN_SAMPLEAPP_VIEW_NOT_INITIALIZED,
    EN_SAMPLEAPP_DEFAULT_MAP_CREATION_FAILED
}EN_SAMPLEAPP_ERRORCODE;

struct RGB {
        U1 r, g, b;
};

struct BGR {
        U1 b, g, r;
};

class utility
{
public:
    utility();
    EN_SAMPLEAPP_ERRORCODE GetFileName(S1 *u1_prefix, U4 u4_index, S1 *pFileName);
    EN_SAMPLEAPP_ERRORCODE LoadBitmap_24RGB(const S1 *u1_fileName, S4 s4_sizeX, S4 s4_sizeY, S4 s4_dataSize, U1 *u1_out);
    EN_SAMPLEAPP_ERRORCODE LoadMapFromFile(const char *pFileName,U1 *u1_mapdata,S4 s4_size);
    EN_SAMPLEAPP_ERRORCODE StoreMapToFile(const char *pFileName,const U1 *u1_mapdata,S4 s4_size);
    void DisplayErrorMessage(EN_SAMPLEAPP_ERRORCODE en_sampleapp_err);
};

#endif // UTILITY_H
