#ifndef WINDOWUTILITY_H
#define WINDOWUTILITY_H

/************************************************************************************************/
/* Name         : windowutility.h                                                               */
/* Content      : Windows utility class to draw the window to display the processed image       */
/* Note         :                                                                               */
/* Version      : V1.00  31-07-2014   Johnson George           Initial version.                 */
/************************************************************************************************/


#ifdef DESKTOP_BUILD_WINDOWS
#define WIN32_LEAN_AND_MEAN 1
#include <windows.h>
#include <stdio.h>
#elif defined DESKTOP_BUILD_LINUX
#include <stdio.h>
#include <stdlib.h>
#include <X11/Xlib.h>
#include <X11/Xatom.h>
#include <sched.h>
#include <unistd.h>
#else   /* Target */
#include <stdlib.h>
#include <stdio.h>
#include <sched.h>
#include <unistd.h>
#endif

#include <GLES2/gl2.h>
#include <EGL/egl.h>

class windowutility
{
private:
    void* m_displayHandle;
    void* m_windowHandle;
public:
    windowutility();
    void *CreateDisplay();
    void CloseWindow();
    void CloseDisplay();
    void *CreateMainWindow(const char *pTitle, int nWidth, int nHeight);
};

#endif // WINDOWUTILITY_H
