/************************************************************************************************/
/* Name         : windowutility.cpp                                                                   */
/* Content      : Windows utility class to draw the window to display the processed image       */
/* Note         : Sample application for demonstrating the VP1 Software                         */
/* Version      : V1.00  31-07-2014   Johnson George           Initial version.                 */
/************************************************************************************************/

#include "windowutility.h"

windowutility::windowutility()
{
    m_displayHandle = NULL;
    m_windowHandle = NULL;
    /* Constructor */
}

/************************************************************************************************/
/* Name         : CreateDisplay                                                                 */
/* Function     : This function creates the display for displaying the image                    */
/* Argument     : None                                                                          */
/* Return values: Window Handle                                                                 */
/* Note         :                                                                               */
/* remarks      :                                                                               */
/* version      : v1.00   30-06-2014     1.0 Window Creation Utility Class Initial version.     */
/************************************************************************************************/
void* windowutility::CreateDisplay()
{
#ifdef DESKTOP_BUILD_WINDOWS
    HDC			hDisplay = 0;
    hDisplay = EGL_DEFAULT_DISPLAY;
#elif defined DESKTOP_BUILD_LINUX
    Display		*hDisplay = NULL;
    hDisplay = XOpenDisplay(NULL);
    if (!hDisplay)
    {
        fprintf(stderr, "ERROR: unable to get display!n\n");
        return 0;
    } else {/* NOP */}
#elif defined TARGET_BUILD
    EGLNativeDisplayType        hDisplay;
    hDisplay = fbGetDisplay(NULL);
#else
    // Do Nothing
#endif
    /* keep hDisplay locally */
    m_displayHandle = hDisplay;
    return (void *)hDisplay;
}

/************************************************************************************************/
/* Name         : process_window                                                                 */
/* Function     : Call back function to handle the windows events                               */
/* Argument     : None                                                                          */
/* Return values: Status of operation                                                           */
/* Note         :                                                                               */
/* remarks      :                                                                               */
/* version      : v1.00   30-06-2014     1.0 Window Creation Utility Class Initial version.     */
/************************************************************************************************/
#ifdef DESKTOP_BUILD_WINDOWS
static LRESULT CALLBACK process_window(HWND hWnd, UINT uiMsg, WPARAM wParam, LPARAM lParam)
{
    switch(uiMsg)
    {
        case WM_CLOSE:
        {
            PostQuitMessage(0);
            return 0;
        }
        case WM_ACTIVATE:
            break;
        case WM_KEYDOWN:
        break;

        case WM_KEYUP:
             break;
        case WM_SIZE:
             break;
        case WM_LBUTTONDOWN:
            break;
        case WM_LBUTTONUP:
            break;
        default:
            return DefWindowProc(hWnd, uiMsg, wParam, lParam);
    }
    return 0;
}

/************************************************************************************************/
/* Name         : UTF8toUTF16                                                                   */
/* Function     : Converts the string from UTF8 to UTF16 format                                 */
/* Argument     : None                                                                          */
/* Return values: LPCWSTR                                                                       */
/* Note         :                                                                               */
/* remarks      :                                                                               */
/* version      : v1.00   30-06-2014     1.0 Window Creation Utility Class Initial version.     */
/************************************************************************************************/
static LPCWSTR UTF8toUTF16(LPCSTR utf8)
{
   static char utf16[200] = {0};
   unsigned int nLen = 0;

   utf16[0]= utf16[1] =0;
   nLen = MultiByteToWideChar(CP_UTF8, 0, utf8, -1, NULL, 0);
   if ((nLen>1) && (nLen < sizeof(utf16))) {
      MultiByteToWideChar(CP_UTF8, 0, utf8, -1, (LPWSTR)utf16, nLen);
   } else {/* NOP */}
   return (LPCWSTR)utf16;
}

/************************************************************************************************/
/* Name         : CreateMainWindow                                                              */
/* Function     : Create the window to display the image                                        */
/* Argument     : Title of the window                                                           */
/*              : Width of the window                                                           */
/*              : Height of the window                                                          */
/* Return values: LPCWSTR                                                                       */
/* Note         :                                                                               */
/* remarks      :                                                                               */
/* version      : v1.00   30-06-2014     1.0 Window Creation Utility Class Initial version.     */
/************************************************************************************************/
void* windowutility::CreateMainWindow(const char *pTitle, int nWidth, int nHeight)
{
    WNDCLASS wc;
    RECT wRect;
    HWND hWindow;
    HINSTANCE hInstance;

    wRect.left = 0L;
    wRect.right = (long)nWidth;
    wRect.top = 0L;
    wRect.bottom = (long)nHeight;

    hInstance = GetModuleHandle(NULL);
    wc.style = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
    wc.lpfnWndProc = (WNDPROC)process_window;
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;
    wc.hInstance = hInstance;
    wc.hIcon = LoadIcon(NULL, IDI_WINLOGO);
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = NULL;
    wc.lpszMenuName = NULL;
    wc.lpszClassName = UTF8toUTF16("OGLES");

    RegisterClass(&wc);
    AdjustWindowRectEx(&wRect, WS_OVERLAPPEDWINDOW, FALSE, WS_EX_APPWINDOW | WS_EX_WINDOWEDGE);
    hWindow = CreateWindowEx(WS_EX_APPWINDOW | WS_EX_WINDOWEDGE,
             UTF8toUTF16("OGLES"), UTF8toUTF16(pTitle), WS_OVERLAPPEDWINDOW | WS_CLIPSIBLINGS | WS_CLIPCHILDREN, 0, 0, nWidth, nHeight, NULL, NULL, hInstance, NULL);

    ShowWindow(hWindow, SW_SHOW);
    SetForegroundWindow(hWindow);
    SetFocus(hWindow);

    /* Save handle locally. */
    m_windowHandle = hWindow;
    return (void *)hWindow;
#elif defined DESKTOP_BUILD_LINUX
/* Creates an X window */
void * windowutility::CreateMainWindow(const char *pTitle, int nWidth, int nHeight)
{
    Display * hDisplay = (Display *)m_displayHandle;
    Window root  =  DefaultRootWindow(hDisplay );   // get the root window (usually the whole screen)
    Window hWindow;

    XSetWindowAttributes  swa;
    swa.event_mask  =  StructureNotifyMask | ExposureMask | PointerMotionMask | KeyPressMask;
    swa.override_redirect = True;
    hWindow  =  XCreateWindow (hDisplay, root,0, 0, nWidth, nHeight,0,CopyFromParent, InputOutput,CopyFromParent, CWEventMask,&swa );
    XMapWindow(hDisplay, hWindow);
    XStoreName(hDisplay, hWindow, pTitle);
   /* Save handle locally. */
    m_windowHandle = (void*)hWindow;
    return (void *)hWindow;
#else
void * windowutility::CreateMainWindow(const char *pTitle, int nWidth, int nHeight)
{
    /* Create full size window */
    EGLNativeWindowType  hWindow = fbCreateWindow((EGLNativeDisplayType)m_displayHandle, 0, 0, nWidth,nHeight);

    /* Save window handle locally. */
    m_windowHandle = hWindow;
    return (void *)hWindow;
#endif /* _WIN32 */
}

/************************************************************************************************/
/* Name         : CloseWindow                                                                   */
/* Function     : Close the window                                                              */
/* Argument     : None                                                                          */
/* Return values: None                                                                          */
/* Note         :                                                                               */
/* remarks      :                                                                               */
/* version      : v1.00   30-06-2014     1.0 Window Creation Utility Class Initial version.     */
/************************************************************************************************/
void windowutility::CloseWindow()
{
#ifdef DESKTOP_BUILD_WINDOWS
    //TBD
#elif defined DESKTOP_BUILD_LINUX
    XDestroyWindow((Display *)m_displayHandle, (Window)m_windowHandle);
#else
    fbDestroyWindow(EGLNativeWindowType(m_windowHandle));
#endif

}

/************************************************************************************************/
/* Name         : CloseDisplay                                                                  */
/* Function     : Close the display                                                             */
/* Argument     : None                                                                          */
/* Return values: None                                                                          */
/* Note         :                                                                               */
/* remarks      :                                                                               */
/* version      : v1.00   30-06-2014     1.0 Window Creation Utility Class Initial version.     */
/************************************************************************************************/
void windowutility::CloseDisplay()
{
#ifdef DESKTOP_BUILD_WINDOWS
    // Do nothing for Windows
#elif defined DESKTOP_BUILD_LINUX
    XCloseDisplay((Display*)m_displayHandle);
#else
    fbDestroyDisplay((EGLNativeDisplayType)m_displayHandle);
#endif
}
