#ifndef VPCORE_SETTING_H
#define VPCORE_SETTING_H

#if defined (VPCORE_V2_5) || defined (VPCORE_V3_0)
extern "C" {
#include "vp_core.h"
}
#else
#include "vp_core.h"
#endif //VPCORE_V2_5

#ifdef VPCORE_V2_5
#include "can_v2.5.h"
#elif defined VPCORE_V3_0
#include "can_v3.0.h"
#else
#include "can_v4.0.h"
#endif

#ifdef VPCORE_V2_5
#define VP_CORE_MEMSIZE                             (6575700)
#elif defined VPCORE_V3_0
#define VP_CORE_MEMSIZE                             (8672852)
#endif //VPCORE_V2_5

#define IMAGE_WIDTH                                 640
#define IMAGE_HEIGHT                                480

#ifdef VPCORE_V2_5
#define VEHICLE_PARAM_LENGTH                        4428
#define VEHICLE_PARAM_WIDTH                         1826
#define VEHICLE_PARAM_WHEELBASE                     2785
#define VEHICLE_PARAM_REAR_OVERHANG                 764
#define VEHICLE_PARAM_STEERING_ANGLE_FACTOR         0
#define VEHICLE_PARAM_WHEEL_CIRCUMFRENCE            2050.0
#define VEHICLE_PARAM_WHEEL_PULSE                   48.0
#define VEHICLE_PARAM_REAR_BUMPER_EDGE_HEIGHT       0
#define VEHICLE_PARAM_MAX_STEER_ANGLE               {-544.4,544.4}
#define VEHICLE_PARAM_MAX_WHEEL_ANGLE               {-37.27, 37.27}
#elif defined VPCORE_V3_0
#define VEHICLE_PARAM_LENGTH                        4428
#define VEHICLE_PARAM_WIDTH                         1826
#define VEHICLE_PARAM_WHEELBASE                     2785
#define VEHICLE_PARAM_REAR_OVERHANG                 764
#define VEHICLE_PARAM_WHEEL_CIRCUMFRENCE            2050.0
#define VEHICLE_PARAM_WHEEL_PULSE                   48.0
#define VEHICLE_PARAM_REAR_BUMPER_EDGE_HEIGHT       0
#define VEHICLE_PARAM_MAX_STEER_ANGLE               {-544.4,544.4}
#define VEHICLE_PARAM_MAX_WHEEL_ANGLE               {-37.27, 37.27}
#else
#define VEHICLE_PARAM_WIDTH                         1853            /* Vehicle overall width[mm] */
#define VEHICLE_PARAM_WHEELBASE                     2817            /* Wheelbase[mm] */
#define VEHICLE_PARAM_REAR_OVERHANG                 774             /* Rear overhang (mm) */
#define VEHICLE_PARAM_FRONT_OVERHANG                879             /* Front overhang (mm) */
#define VEHICLE_PARAM_WHEEL_CIRCUMFRENCE            2055            /* Tyre circumference[mm] */
#define VEHICLE_PARAM_WHEEL_PULSE                   48              /* Number of pulses per tyre 1 round */
#define VEHICLE_PARAM_REAR_BUMPER_EDGE_HEIGHT       540.0f          /* Bumper area border (Y direction) */
#define VEHICLE_TRAILER_HOOK_LENGTH                 200U            /* Trailer hook lenght (mm) */
#define VEHICLE_TRAILER_HOOK_HEIGHT                 500U            /* Trailer hook height (mm) */
#define VEHICLE_PARAM_MAX_LINER_STEER_ANGLE         3600U            /* Max steer rudder corner(r&l)[deg] */
#define VEHICLE_PARAM_MAX_LINEAR_WHEEL_ANGLE        232U             /* Corner run out of max wheel(r&l)[deg] */
#define VEHICLE_PARAM_MAX_STEER_ANGLE               5440U            /* TBD */
#define VEHICLE_PARAM_MAX_WHEEL_ANGLE               373U             /* TBD */
#endif //VPCORE_V2_5

#ifdef VPCORE_V2_5
#define CAMERA_PARAM_X_POSITION                     -261.714630
#define CAMERA_PARAM_Y_POSITION                     -87.068359
#define CAMERA_PARAM_Z_POSITION                     822.351318
#define CAMERA_PARAM_ROLL_ANGLE                     -0.570003
#define CAMERA_PARAM_PITCH                          63.800003
#define CAMERA_PARAM_YAW                            179.523102
#define CAMERA_PARAM_FOCUS                          1.53600001
#define CAMERA_PARAM_OPTICAL_AXIS_CENTER_U          0
#define CAMERA_PARAM_OPTICAL_AXIS_CENTER_V          0
#define CAMERA_PARAM_OPTICAL_AXIS_CENTER_GAP_U      0
#define CAMERA_PARAM_OPTICAL_AXIS_CENTER_GAP_V      0
#define CAMERA_PARAM_IMAGE_HIGH_GAP                 0
#define CAMERA_PARAM_OPTICAL_AXIS_CENTER1_GAP_U     0
#define CAMERA_PARAM_OPTICAL_AXIS_CENTER1_GAP_V     0
#define CAMERA_PARAM_PITCH_SENSOR_U                 0
#define CAMERA_PARAM_PITCH_SENSOR_V                 0
#else
#define CAMERA_PARAM_X_POSITION                     -4341           /* Camera X position[mm]. */
#define CAMERA_PARAM_Y_POSITION                     -262            /* Camera Y position[mm]. */
#define CAMERA_PARAM_Z_POSITION                     822             /* Camera Z position[mm]. */
#define CAMERA_PARAM_ROLL_ANGLE                     0               /* Roll angle[deg]. */
#define CAMERA_PARAM_PITCH                          26.2            /* Pitch angle[deg]. */
#define CAMERA_PARAM_YAW                            0               /* Yaw angle[deg]. */
#endif //VPCORE_V2_5

#ifdef VPCORE_V4_0
/* Trajectory line setting */
#define TRAJECTORY_LINE_R_INDEX                     0
#define TRAJECTORY_LINE_G_INDEX                     255
#define TRAJECTORY_LINE_B_INDEX                     255
#define TRAJECTORY_LINE_A_INDEX                     255

#define DISTANCE_REAR_LINE_TRAJECTORY_R_INDEX       0
#define DISTANCE_REAR_LINE_TRAJECTORY_G_INDEX       255
#define DISTANCE_REAR_LINE_TRAJECTORY_B_INDEX       0
#define DISTANCE_REAR_LINE_TRAJECTORY_A_INDEX       255

#define DISTANCE_MIDDLE_LINE_TRAJECTORY_R_INDEX     255
#define DISTANCE_MIDDLE_LINE_TRAJECTORY_G_INDEX     255
#define DISTANCE_MIDDLE_LINE_TRAJECTORY_B_INDEX     0
#define DISTANCE_MIDDLE_LINE_TRAJECTORY_A_INDEX     255

#define DISTANCE_START_LINE_TRAJECTORY_R_INDEX      255
#define DISTANCE_START_LINE_TRAJECTORY_G_INDEX      128
#define DISTANCE_START_LINE_TRAJECTORY_B_INDEX      0
#define DISTANCE_START_LINE_TRAJECTORY_A_INDEX      255

#define DISTANCE_START_LINE_WIDTH_IN_PIXEL          11
#define DISTANCE_MIDDLE_LINE_WIDTH_IN_PIXEL         6
#define DISTANCE_REAR_LINE_WIDTH_IN_PIXEL           3
#define TRAJECTORY_LINE_WIDTH_IN_PIXEL              10

#define VIEW_CONTROL_BRIGHTNESS_LIMIT_DIFF          100
#define VIEW_CONTROL_TARGET_BRIGHTNESS              100
#define VIEW_CONTROL_TOP_VIEW_HEIGHT                1500
#endif

#if defined (VPCORE_V3_0) || defined (VPCORE_V4_0)
#define CALIB_TARGET_INFO_RIGHT_RB_s4_x              -5050
#define CALIB_TARGET_INFO_RIGHT_RB_s4_y              -1500
#define CALIB_TARGET_INFO_RIGHT_RT_s4_x              -4550
#define CALIB_TARGET_INFO_RIGHT_RT_s4_y              -1500
#define CALIB_TARGET_INFO_RIGHT_LB_s4_x              -5050
#define CALIB_TARGET_INFO_RIGHT_LB_s4_y              -1100
#define CALIB_TARGET_INFO_RIGHT_LT_s4_x              -4550
#define CALIB_TARGET_INFO_RIGHT_LT_s4_y              -1100

#define CALIB_TARGET_INFO_MIDDLE_RB_s4_x            -5050
#define CALIB_TARGET_INFO_MIDDLE_RB_s4_y            -300
#define CALIB_TARGET_INFO_MIDDLE_RT_s4_x            -4550
#define CALIB_TARGET_INFO_MIDDLE_RT_s4_y            -300
#define CALIB_TARGET_INFO_MIDDLE_LB_s4_x            -5050
#define CALIB_TARGET_INFO_MIDDLE_LB_s4_y            300
#define CALIB_TARGET_INFO_MIDDLE_LT_s4_x            -4550
#define CALIB_TARGET_INFO_MIDDLE_LT_s4_y            300

#define CALIB_TARGET_INFO_LEFT_RB_s4_x              -5050
#define CALIB_TARGET_INFO_LEFT_RB_s4_y              1100
#define CALIB_TARGET_INFO_LEFT_RT_s4_x              -4550
#define CALIB_TARGET_INFO_LEFT_RT_s4_y              1100
#define CALIB_TARGET_INFO_LEFT_LB_s4_x              -5050
#define CALIB_TARGET_INFO_LEFT_LB_s4_y              1500
#define CALIB_TARGET_INFO_LEFT_LT_s4_x              -4550
#define CALIB_TARGET_INFO_LEFT_LT_s4_y              1500
#endif

#define LOOP_COUNT                                  9

#define CALIBRATION_INITIALIZATION_NOT_COMPLETED    0
#define CALIBRATION_INITIALIZATION_COMPLETED        1

#define VIEW_INITIALIZATION_NOT_COMPLETED           0
#define VIEW_INITIALIZATION_COMPLETED               1

#endif // VPCORE_SETTING_H
