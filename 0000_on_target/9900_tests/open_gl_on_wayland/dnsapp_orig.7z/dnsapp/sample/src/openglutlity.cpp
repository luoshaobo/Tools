/************************************************************************************************/
/* Name         : openglutility.cpp                                                             */
/* Content      : Helper function for opengl interfaces                                         */
/* Note         : Sample application for demonstrating the VP1 Software                         */
/* Version      : V1.00  31-07-2014   Johnson George           Initial version.                 */
/************************************************************************************************/

#include "openglutlity.h"

openglutlity::openglutlity()
{
}

/************************************************************************************************/
/* Name         : app_gl_init_opengl                                                            */
/* Function     : This function initializes the OpenGL for display                              */
/* Argument     : None                                                                          */
/* Return values: TRUE                                                                          */
/*              : FALSE                                                                         */
/* Note         :                                                                               */
/* remarks      :                                                                               */
/* version      : V1.00   30-06-2014     1.0 OpenGL Utility Class Initial version.              */
/************************************************************************************************/
BL openglutlity::app_gl_init_opengl()
{
    void        *hDisplay = NULL;
    void        *hWindow = NULL;
    EGLint      eglint_majorVersion = 0;
    EGLint      eglint_minorVersion = 0;
    EGLint      eglint_matchingConfigs = 0;
    EGLConfig   egl_configs[10];

    m_app_ScreenWidth = FORM_DISP_WIDTH;
    m_app_ScreenHeight = FORM_DISP_HEIGHT;

    hDisplay = m_windowutil.CreateDisplay();
    m_gl_Display = eglGetDisplay((EGLNativeDisplayType)hDisplay);
    if (m_gl_Display == EGL_NO_DISPLAY) {
        app_egl_err_handler(eglGetError());
        return FALSE;
    } else {/*NOP*/}

    if (!eglInitialize(m_gl_Display, &eglint_majorVersion, &eglint_minorVersion)) {
        app_egl_err_handler(eglGetError());
        return FALSE;
    } else {/* NOP */}

    if(!eglChooseConfig(m_gl_Display, configAttribs, &egl_configs[0], 10,  &eglint_matchingConfigs)) {
        app_egl_err_handler(eglGetError());
        return FALSE;
    } else {/* NOP */}

    if (eglint_matchingConfigs < 1) {
        return FALSE;
    } else {/* NOP */}

    hWindow = m_windowutil.CreateMainWindow("Visio Park", m_app_ScreenWidth,m_app_ScreenHeight);
    m_gl_Surface = eglCreateWindowSurface(m_gl_Display, egl_configs[0],(EGLNativeWindowType)hWindow, 0);

    if(m_gl_Surface == EGL_NO_SURFACE) {
        app_egl_err_handler(eglGetError());
        return FALSE;
    } else {/* NOP */}

    eglBindAPI(EGL_OPENGL_ES_API);
    m_gl_Context = eglCreateContext(m_gl_Display, egl_configs[0], EGL_NO_CONTEXT, contextAttribs);
    if (m_gl_Context == EGL_NO_CONTEXT) {
        app_egl_err_handler(eglGetError());
        return FALSE;
    } else {/* NOP */}

    if (!eglMakeCurrent(m_gl_Display, m_gl_Surface, m_gl_Surface, m_gl_Context)) {
        app_egl_err_handler(eglGetError());
        return FALSE;
    } else {/* NOP */}

    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    eglSwapInterval(m_gl_Display, 0);
    glDisable(GL_BLEND);
    //glColorMask(true, true, true, false); // mask off the alpha buffer channel

    app_gl_ortho2D(0, (GLfloat)m_app_ScreenWidth, (GLfloat)m_app_ScreenHeight, 0, &m_app_projMat );
    m_app_tpv_texture = app_gl_createTexture(NULL, (U2)TOPVIEW_WIDTH, (U2)TOPVIEW_HEIGHT, GL_RGBA, GL_LINEAR, GL_CLAMP_TO_EDGE);		/* Top View */
    m_app_ctv_texture = app_gl_createTexture(NULL, (U2)CUSTOMVIEW_WIDTH, (U2)CUSTOMVIEW_HEIGHT, GL_RGBA, GL_LINEAR, GL_CLAMP_TO_EDGE);	/* Custom View */
    m_app_cam_img_texture = app_gl_createTexture(NULL, (U2)CAM_IMG_WIDTH,    (U2)CAM_IMG_HEIGHT,    GL_RGB,  GL_LINEAR, GL_CLAMP_TO_EDGE);

    m_app_tpv_framebuf = app_gl_createFrameBuffer(TOPVIEW_WIDTH, TOPVIEW_HEIGHT, m_app_tpv_texture);        /* Top View */
    m_app_ctv_framebuf = app_gl_createFrameBuffer(CUSTOMVIEW_WIDTH, CUSTOMVIEW_HEIGHT, m_app_ctv_texture);	/* Custom View */
    m_app_cam_img_framebuf = app_gl_createFrameBuffer(CAM_IMG_WIDTH, CAM_IMG_HEIGHT, m_app_cam_img_texture);

    app_gl_TexShader();
    return TRUE;
}

/************************************************************************************************/
/* Name         : app_gl_term_opengl                                                            */
/* Function     : This function will terminate the openGL & closes the window & display         */
/* Argument     : None                                                                          */
/* Return values: None                                                                          */
/* Note         :                                                                               */
/* remarks      :                                                                               */
/* version      : v1.00   30-06-2014     1.0 OpenGL Utility Class Initial version.              */
/************************************************************************************************/
void openglutlity::app_gl_term_opengl()
{
    if (m_gl_Display != EGL_NO_DISPLAY) {
        eglMakeCurrent(m_gl_Display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (m_gl_Context != EGL_NO_CONTEXT) {
            eglDestroyContext(m_gl_Display, m_gl_Context);
        }else {/* NOP */}
        if (m_gl_Surface != EGL_NO_SURFACE) {
            eglDestroySurface(m_gl_Display, m_gl_Surface);
        }else {/* NOP */}
        eglTerminate(m_gl_Display);
    } else {/* NOP */}
    m_gl_Display = EGL_NO_DISPLAY;
    m_gl_Context = EGL_NO_CONTEXT;
    m_gl_Surface = EGL_NO_SURFACE;
    m_windowutil.CloseWindow();
    m_windowutil.CloseDisplay();
    return;
}

/************************************************************************************************/
/* Name         : app_gl_swapbuffers                                                            */
/* Function     : This function post EGL surface color buffer to native window                  */
/* Argument     : None                                                                          */
/* Return values: None                                                                          */
/* Note         :                                                                               */
/* remarks      :                                                                               */
/* version      : v1.00   30-06-2014     1.0 OpenGL Utility Class Initial version.              */
/************************************************************************************************/
void openglutlity::app_gl_swapbuffers()
{
    eglSwapBuffers(m_gl_Display, m_gl_Surface);
    return;
}

/************************************************************************************************/
/* Name         : app_gl_draw                                                                   */
/* Function     : This function is used to draw the top & custom view                           */
/* Argument     : None                                                                          */
/* Return values: None                                                                          */
/* Note         :                                                                               */
/* remarks      :                                                                               */
/* version      : v1.00   30-06-2014     1.0 OpenGL Utility Class Initial version.              */
/************************************************************************************************/
void openglutlity::app_gl_draw()
{
    static F4 f4t_tpv_vert[3 * 4] = {
        (F4)TOPVIEW_L * (F4)FORM_DISP_WIDTH / (F4)OUT_MAX_SIZE_X, (F4)TOPVIEW_T * (F4)FORM_DISP_HEIGHT / (F4)OUT_MAX_SIZE_Y, 0.0f,
        (F4)TOPVIEW_R * (F4)FORM_DISP_WIDTH / (F4)OUT_MAX_SIZE_X, (F4)TOPVIEW_T * (F4)FORM_DISP_HEIGHT / (F4)OUT_MAX_SIZE_Y, 0.0f,
        (F4)TOPVIEW_R * (F4)FORM_DISP_WIDTH / (F4)OUT_MAX_SIZE_X, (F4)TOPVIEW_B * (F4)FORM_DISP_HEIGHT / (F4)OUT_MAX_SIZE_Y, 0.0f,
        (F4)TOPVIEW_L * (F4)FORM_DISP_WIDTH / (F4)OUT_MAX_SIZE_X, (F4)TOPVIEW_B * (F4)FORM_DISP_HEIGHT / (F4)OUT_MAX_SIZE_Y, 0.0f,
    };
    F4 f4t_texCoord[2 * 4] = {
        0.0f, 1.0f,
        1.0f, 1.0f,
        1.0f, 0.0f,
        0.0f, 0.0f,
    };
    static F4 f4t_ctv_vert[3 * 4] = {
        (F4)CUSTOMVIEW_L * (F4)FORM_DISP_WIDTH / (F4)OUT_MAX_SIZE_X, (F4)CUSTOMVIEW_T * (F4)FORM_DISP_HEIGHT / (F4)OUT_MAX_SIZE_Y, 0.0f,
        (F4)CUSTOMVIEW_R * (F4)FORM_DISP_WIDTH / (F4)OUT_MAX_SIZE_X, (F4)CUSTOMVIEW_T * (F4)FORM_DISP_HEIGHT / (F4)OUT_MAX_SIZE_Y, 0.0f,
        (F4)CUSTOMVIEW_R * (F4)FORM_DISP_WIDTH / (F4)OUT_MAX_SIZE_X, (F4)CUSTOMVIEW_B * (F4)FORM_DISP_HEIGHT / (F4)OUT_MAX_SIZE_Y, 0.0f,
        (F4)CUSTOMVIEW_L * (F4)FORM_DISP_WIDTH / (F4)OUT_MAX_SIZE_X, (F4)CUSTOMVIEW_B * (F4)FORM_DISP_HEIGHT / (F4)OUT_MAX_SIZE_Y, 0.0f,
    };

    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    glViewport(0, 0, m_app_ScreenWidth, m_app_ScreenHeight);
    app_gl_polygon(m_app_tpv_texture, f4t_tpv_vert, f4t_texCoord, 4, TRUE, GL_TRIANGLE_FAN, (GLfloat*)&m_app_projMat.m[0][0]);
    app_gl_polygon(m_app_ctv_texture, f4t_ctv_vert, f4t_texCoord, 4, FALSE, GL_TRIANGLE_FAN, (GLfloat*)&m_app_projMat.m[0][0]);
    return;
}

/************************************************************************************************/
/* Name         : app_gl_get_frameinfo                                                          */
/* Function     : This function updates the frame buffer information                            */
/* Argument     : None                                                                          */
/* Return values: Success                                                                       */
/* Note         :                                                                               */
/* remarks      :                                                                               */
/* version      : v1.00   30-06-2014     1.0 OpenGL Utility Class Initial version.              */
/************************************************************************************************/
void openglutlity::app_gl_get_frameinfo(AppGlViewType type, U4 *pu4_id, S4 *ps4_width, S4 *ps4_height)
{
    if (APP_GL_TOPVIEW == type) {
        *pu4_id = m_app_tpv_framebuf;
        *ps4_width = TOPVIEW_WIDTH;
        *ps4_height = TOPVIEW_HEIGHT;
    } else if (APP_GL_CUSTOMVIEW == type) {
        *pu4_id = m_app_ctv_framebuf;
        *ps4_width = CUSTOMVIEW_WIDTH;
        *ps4_height = CUSTOMVIEW_HEIGHT;
    } else{
        *pu4_id     = m_app_cam_img_framebuf;
        *ps4_width  = CAM_IMG_WIDTH;
        *ps4_height = CAM_IMG_HEIGHT;
    }
    return;
}

/************************************************************************************************/
/* Name         : app_gl_LoadShader                                                            */
/* Function     : This function creates the shader , Compiles & check the status                */
/* Argument     : None                                                                          */
/* Return values: Success                                                                       */
/*              : Failure               :Other error codes defined in EN_VP_CORE_RESULT         */
/* Note         :                                                                               */
/* remarks      :                                                                               */
/* version      : v1.00   30-06-2014     1.0 OpenGL Utility Class Initial version.              */
/************************************************************************************************/
GLuint openglutlity::app_gl_LoadShader(GLenum en_type, const char *pShaderSrc)
{
    GLuint shader;
    GLint compiled;

    /* Create the shader object */
    shader = glCreateShader ( en_type );
    if (shader == 0) {
        return 0;
    } else {/* NOP */}
    /* Load the shader source */
    glShaderSource(shader, 1, &pShaderSrc, NULL);
     // Compile the shader
    glCompileShader(shader);
    /* Check the compile status */
    glGetShaderiv(shader, GL_COMPILE_STATUS, &compiled);
    if (!compiled) {
        glDeleteShader(shader);
        return 0;
    } else {/* NOP */}
     return shader;
}

/************************************************************************************************/
/* Name         : app_gl_TexShader                                                            */
/* Function     : This function creates the texture shader                                      */
/* Argument     : None                                                                          */
/* Return values: Success                                                                       */
/* Note         :                                                                               */
/* remarks      :                                                                               */
/* version      : v1.00   30-06-2014     1.0 OpenGL Utility Class Initial version.              */
/************************************************************************************************/
BL openglutlity::app_gl_TexShader()
{
    /* Vertex shader */
    const char vShaderStr[] =
        "attribute vec4 a_position;              \n"
        "attribute vec2 a_texCoord;              \n"
        "varying vec2 v_texCoord;                \n"
        "uniform mat4 u_matrix;                  \n"
        "                                        \n"
        "void main()                             \n"
        "{                                       \n"
        "   v_texCoord = a_texCoord;        \n"
        "   gl_Position = u_matrix * a_position; \n"
        "}";

    /* Fragment shader */
    const char fShaderStr[] =
        "precision mediump float;                                   \n"
        "varying vec2 v_texCoord;                                   \n"
        "uniform sampler2D s_texture;                               \n"
        "                                                           \n"
        "void main()                                                \n"
        "{                                                          \n"
        "	gl_FragColor = texture2D(s_texture, v_texCoord);      \n"
        "}";


    /* shader create common process */
    GLuint vertexShader;
    GLuint fragmentShader;
    GLuint programObject;
    GLint linked;

    // Load the vertex/fragment shaders
    vertexShader = app_gl_LoadShader(GL_VERTEX_SHADER, vShaderStr);
    fragmentShader = app_gl_LoadShader(GL_FRAGMENT_SHADER, fShaderStr);
    if ((vertexShader == 0) || (fragmentShader == 0)) {
        return FALSE;
    } else {/* NOP */}

    // Create the program object
    programObject = glCreateProgram();
    if (programObject == 0) {
        return FALSE;
    } else {/* NOP */}

    glAttachShader(programObject, vertexShader);
    glAttachShader(programObject, fragmentShader);
    // Link the program
    glLinkProgram(programObject);
    // Check the link status
    glGetProgramiv(programObject, GL_LINK_STATUS, &linked);
    if (!linked) {
        glDeleteProgram(programObject);
        return FALSE;
    }
    // Store the program object
    m_app_programObj[APP_GL_SHDPG_TEX] = programObject;

    /* Get the location of the attribute variable */
    /* Vertex co-ordinate */
    m_app_programLoc[APP_GL_SHDPG_TEX].a_position = glGetAttribLocation(programObject, "a_position");
    /* Texture Co-ordinate */
    m_app_programLoc[APP_GL_SHDPG_TEX].a_texCoord = glGetAttribLocation(programObject, "a_texCoord");
    /* Sampler */
    m_app_programLoc[APP_GL_SHDPG_TEX].s_texture = glGetUniformLocation(programObject, "s_texture");
    /* Projection Transformation Matrix */
    m_app_programLoc[APP_GL_SHDPG_TEX].u_matrix = glGetUniformLocation(programObject, "u_matrix");
    return TRUE;
}

/************************************************************************************************/
/* Name         : app_egl_err_handler                                                           */
/* Function     : This function display the OpenGL errors                                       */
/* Argument     : OpenGL Error Code                                                             */
/* Return values: Success                                                                       */
/* Note         :                                                                               */
/* remarks      :                                                                               */
/* version      : v1.00   30-06-2014     1.0 OpenGL Utility Class Initial version.              */
/************************************************************************************************/
void openglutlity::app_egl_err_handler(EGLint egl_err)
{
    switch (egl_err) {
        case EGL_NOT_INITIALIZED:
            printf("[ EGL_NOT_INITIALIZED ]\n");
            break;
        case EGL_BAD_ACCESS:
            printf("[ EGL_BAD_ACCESS ]\n");
            break;
        case EGL_BAD_ALLOC:
            printf("[ EGL_BAD_ALLOC ]\n");
            break;
        case EGL_BAD_ATTRIBUTE:
            printf("[ EGL_BAD_ATTRIBUTE ]\n");
            break;
        case EGL_BAD_CONFIG:
            printf("[ EGL_BAD_CONFIG ]\n");
            break;
        case EGL_BAD_CONTEXT:
            printf(" [ EGL_BAD_CONTEXT ]\n");
            break;
        case EGL_BAD_CURRENT_SURFACE:
            printf(" [ EGL_BAD_CURRENT_SURFACE ]\n");
            break;
        case EGL_BAD_DISPLAY:
            printf(" [ EGL_BAD_DISPLAY ]\n");
            break;
        case EGL_BAD_MATCH:
            printf(" [ EGL_BAD_MATCH ]\n");
            break;
        case EGL_BAD_NATIVE_PIXMAP:
            printf(" [ EGL_BAD_NATIVE_PIXMAP ]\n");
            break;
        case EGL_BAD_NATIVE_WINDOW:
            printf(" [ EGL_BAD_NATIVE_WINDOW ]\n");
            break;
        case EGL_BAD_PARAMETER:
            printf(" [ EGL_BAD_PARAMETER ]\n");
            break;
        case EGL_BAD_SURFACE:
            printf(" [ EGL_BAD_SURFACE ]\n");
            break;
        case EGL_CONTEXT_LOST:
            printf(" [ EGL_CONTEXT_LOST ]\n");
            break;
        default:
            printf(" [ EGL unknown err ]\n");
            break;
    }
    return;
}

/************************************************************************************************/
/* Name         : app_gl_load_identity                                                          */
/* Function     : This function update the EGL Matrix                                           */
/* Argument     : EXT_GL_MATRIX                                                                 */
/* Return values: void                                                                          */
/* Note         :                                                                               */
/* remarks      :                                                                               */
/* version      : v1.00   30-06-2014     1.0 OpenGL Utility Class Initial version.              */
/************************************************************************************************/
void openglutlity::app_gl_load_identity(EXT_GL_MATRIX* mat)
{
    memset(mat, 0, sizeof(EXT_GL_MATRIX));
    mat->m[0][0] = 1.0f;
    mat->m[1][1] = 1.0f;
    mat->m[2][2] = 1.0f;
    mat->m[3][3] = 1.0f;
    return;
}

/************************************************************************************************/
/* Name         : app_gl_ortho                                                                  */
/* Function     : Updates the EXT_GL_MATRIX structure                                           */
/* Argument     : None                                                                          */
/* Return values: None                                                                          */
/* Note         :                                                                               */
/* remarks      :                                                                               */
/* version      : v1.00   30-06-2014     1.0 OpenGL Utility Class Initial version.              */
/************************************************************************************************/
void openglutlity::app_gl_ortho(GLfloat left, GLfloat right, GLfloat bottom, GLfloat top, GLfloat near_z, GLfloat far_z, EXT_GL_MATRIX* mat)
{
    app_gl_load_identity(mat);

    EXT_GL_MATRIX_ITEM(mat, 0, 0) = 2.0f / (right - left);
    EXT_GL_MATRIX_ITEM(mat, 0, 3) = -(right + left) / (right - left);
    EXT_GL_MATRIX_ITEM(mat, 1, 1) = 2.0f / (top - bottom);
    EXT_GL_MATRIX_ITEM(mat, 1, 3) = -(top + bottom) / (top - bottom);
    EXT_GL_MATRIX_ITEM(mat, 2, 2) = -2.0f / (far_z - near_z);
    EXT_GL_MATRIX_ITEM(mat, 2, 3) = -(far_z + near_z) / (far_z - near_z);
    return;
}

/************************************************************************************************/
/* Name         : app_gl_createTexture                                                          */
/* Function     : This function creates the texture                                             */
/* Argument     : Pixel                                                                         */
/*              : Width                                                                         */
/*              : Height                                                                        */
/*              : Format                                                                        */
/*              : Filter                                                                        */
/*              : Wrap                                                                          */
/* Return values: Texture                                                                       */
/* Note         :                                                                               */
/* remarks      :                                                                               */
/* version      : v1.00   30-06-2014     1.0 OpenGL Utility Class Initial version.              */
/************************************************************************************************/
GLuint openglutlity::app_gl_createTexture(U1* pixels, U2 w, U2 h, S4 format, S4 filter, S4 wrap)
{
    GLuint texture;
    glActiveTexture(GL_TEXTURE0);
    glGenTextures(1, &texture);
    glBindTexture(GL_TEXTURE_2D, texture);
    glTexImage2D(GL_TEXTURE_2D, 0, format, (GLsizei)w, (GLsizei)h, 0, format, GL_UNSIGNED_BYTE, pixels);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, filter);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, filter);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, wrap);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, wrap);
    return texture;
}

/************************************************************************************************/
/* Name         : app_gl_createFrameBuffer                                                      */
/* Function     : This function create the frame buffer for OpenGL display                      */
/* Argument     : Width                                                                         */
/*              : Height                                                                        */
/*              : TextureID                                                                     */
/* Return values: FrameBuffer ID                                                                */
/* Note         :                                                                               */
/* remarks      :                                                                               */
/* version      : v1.00   30-06-2014     1.0 OpenGL Utility Class Initial version.              */
/************************************************************************************************/
GLuint openglutlity::app_gl_createFrameBuffer(S4 width, S4 height, S4 targetTextureId)
{
    GLuint framebuffer;
    GLuint depthbuffer;

    glGenFramebuffers(1, &framebuffer);
    glBindFramebuffer(GL_FRAMEBUFFER, framebuffer);
    glGenRenderbuffers(1, &depthbuffer);
    glBindRenderbuffer(GL_RENDERBUFFER, depthbuffer);
    glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT16, width, height);

    /* Confirm the renderbuf size */
    GLint backingWidth;
    GLint backingHeight;
    glGetRenderbufferParameteriv(GL_RENDERBUFFER, GL_RENDERBUFFER_WIDTH, &backingWidth);
    glGetRenderbufferParameteriv(GL_RENDERBUFFER, GL_RENDERBUFFER_HEIGHT, &backingHeight);
    glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, depthbuffer);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, targetTextureId, 0);
    S4 status = glCheckFramebufferStatus(GL_FRAMEBUFFER);

    if (status != GL_FRAMEBUFFER_COMPLETE) {
        printf("Framebuffer is not complete : status(%ld)\n", status);
    } else {/* NOP */}

    glDisable(GL_DEPTH_TEST);
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    return framebuffer;
}

/************************************************************************************************/
/* Name         : app_gl_polygon                                                                */
/* Function     :                                                                               */
/* Argument     : None                                                                          */
/* Return values: None                                                                          */
/* Note         :                                                                               */
/* remarks      :                                                                               */
/* version      : v1.00   30-06-2014     1.0 OpenGL Utility Class Initial version.              */
/************************************************************************************************/
void openglutlity::app_gl_polygon(GLuint texture, GLfloat* vertices, GLfloat* vTexCoord, S4 s4_num, BL bl_blend, S4 s4_type, GLfloat* projMatrix)
{
    /* Do not process the if the vertex is less than or equal to 0 */
    if (s4_num <= 0) {
        return;
    } else {/* NOP */}

    if (bl_blend) {
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    } else {/* NOP */}

    /* Selection of program object */
    glUseProgram(m_app_programObj[APP_GL_SHDPG_TEX]);

    // projection matrix
    if (projMatrix) {
        glUniformMatrix4fv(m_app_programLoc[APP_GL_SHDPG_TEX].u_matrix, 1, GL_FALSE, projMatrix);
    } else {
        glUniformMatrix4fv(m_app_programLoc[APP_GL_SHDPG_TEX].u_matrix, 1, GL_FALSE, (GLfloat*)&m_app_projMat.m[0][0]);
    }

    /*** Texture ***/
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, texture);
    glUniform1i(m_app_programLoc[APP_GL_SHDPG_TEX].s_texture, 0);

    /* Registration of Texture Co-ordinate */
    glVertexAttribPointer(m_app_programLoc[APP_GL_SHDPG_TEX].a_texCoord, 2, GL_FLOAT, GL_FALSE, 0, vTexCoord);
    glEnableVertexAttribArray(m_app_programLoc[APP_GL_SHDPG_TEX].a_texCoord);

    /* Vertex Data Registration */
    glVertexAttribPointer(m_app_programLoc[APP_GL_SHDPG_TEX].a_position, 3, GL_FLOAT, GL_FALSE, 0, vertices);
    glEnableVertexAttribArray(m_app_programLoc[APP_GL_SHDPG_TEX].a_position);

    /* Drawing */
    glDrawArrays(s4_type, 0, s4_num);
    if (bl_blend) {
        glDisable(GL_BLEND);
    } else {/* NOP */}
    return;
}

void openglutlity::app_update_cam_img(U1 *pu1_data)
{
    /* Activate target texture specified in "cu4_tex". */
    glActiveTexture(
        GL_TEXTURE0
    );

    glBindTexture(
        GL_TEXTURE_2D,
        ( GLuint )m_app_cam_img_texture
    );

    /* Redraw given data into activated texture buffer. */
    glTexSubImage2D(
        GL_TEXTURE_2D,
        0,
        0,
        0,
        ( GLsizei )CAM_IMG_WIDTH,
        ( GLsizei )CAM_IMG_HEIGHT,
        GL_RGB,
        GL_UNSIGNED_BYTE,
        pu1_data
    );
}
