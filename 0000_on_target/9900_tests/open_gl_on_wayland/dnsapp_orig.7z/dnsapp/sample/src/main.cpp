/************************************************************************************************/
/* Name         : main.cpp                                                                      */
/* Content      : Main function for vpcore test application based on V3.0 software release      */
/* Note         : Sample application for demonstrating the VP1 Software usage                   */
/* Version      : V1.00  31-07-2014   Johnson George           Initial version.                 */
/************************************************************************************************/

#include <stdio.h>
#include "openglutlity.h"
#include "utility.h"
#include "vpcore_setting.h"

/* Vehicle parameter, this is a input for vpcore library */
static ST_VP_CORE_VEHICLE_PARAM       stg_vehicle_param = {
                                                            VEHICLE_PARAM_LENGTH,                   /* Vehicle overall length[mm] */
                                                            VEHICLE_PARAM_WIDTH,                    /* Vehicle overall width[mm] */
                                                            VEHICLE_PARAM_WHEELBASE,                /* Wheelbase[mm] */
                                                            VEHICLE_PARAM_REAR_OVERHANG,            /* Real overhang (mm) */
                                                            VEHICLE_PARAM_WHEEL_CIRCUMFRENCE,       /* Tyre circumference[mm] */
                                                            VEHICLE_PARAM_WHEEL_PULSE,              /* Number of pulses per tyre 1 round */
                                                            VEHICLE_PARAM_REAR_BUMPER_EDGE_HEIGHT,  /* Bumper area border (Y direction) */
                                                            VEHICLE_PARAM_MAX_STEER_ANGLE,          /* Max steer rudder corner(r&l)[deg] */
                                                            VEHICLE_PARAM_MAX_WHEEL_ANGLE           /* Corner run out of max wheel(r&l)[deg] */
                                                           };
/* Camera Vehicle coordinate system */
static ST_VP_CORE_CAMERA_POS_INFO stg_camera_pos_param= {
                                                            CAMERA_PARAM_X_POSITION,                /* Camera X position[mm]. */
                                                            CAMERA_PARAM_Y_POSITION,                /* Camera Y position[mm]. */
                                                            CAMERA_PARAM_Z_POSITION,                /* Camera Z position[mm]. */
                                                            CAMERA_PARAM_ROLL_ANGLE,                /* Roll angle[deg]. */
                                                            CAMERA_PARAM_PITCH,                     /* Pitch angle[deg]. */
                                                            CAMERA_PARAM_YAW                        /* Yaw angle[deg]. */
                                                        };
static U1 au1g_vpcoremem[VP_CORE_MEMSIZE];

/* Entry Point of the vpcore test application */
int main()
{
    U1                              au1t_vp_camera_image[IMAGE_WIDTH * IMAGE_HEIGHT * 3] = {0};
    U4                              u4t_loop_num = 0;
    BL                      blt_return_status = 0;
    ST_VP_CORE_RESOURCES            stt_vpcore_resource;
    EN_VP_CORE_RESULT       ent_vp_core_return = VP_CORE_RESULT_SUCCESS;
    EN_VP_CORE_CONTEXTUAL_VIEW_MODE ent_vpcore_view = VP_CORE_CONTEXTUAL_VIEW_MODE_REAR_VIEW;
    ST_VP_CORE_IMAGE_OBJ            stt_img;
    EN_SAMPLEAPP_ERRORCODE          ent_app_return = EN_SAMPLEAPP_STATUS_SUCCESS;
    S1                              as1t_FileName[MAX_FILE_NAME_SIZE] = {0};
    S1                              as1t_Camera_image_name[] = "C:/multicam_data/DS-data/DATA/BOSCH/LineAlignment/bv/image00/Data_";
    openglutlity                    OpenGLIns;
    utility                         Util;

    memset(au1g_vpcoremem,0,VP_CORE_MEMSIZE);
    memset(&stt_img,0,sizeof(ST_VP_CORE_IMAGE_OBJ));
    memset(&stt_vpcore_resource,0,sizeof(ST_VP_CORE_RESOURCES));
#ifndef DESKTOP_BUILD_WINDOWS
    system("stty raw -echo");
#endif
    stt_vpcore_resource.st_memory_pool.pu1_buffer = au1g_vpcoremem;
    stt_vpcore_resource.st_memory_pool.s4_size = VP_CORE_MEMSIZE;

    /* OpenGL Initialization */
    blt_return_status = OpenGLIns.app_gl_init_opengl();
    if(false == blt_return_status) {
        printf("main::OpenGL Initialization Failed err(%d)\n",blt_return_status);
        ent_app_return = EN_SAMPLEAPP_STATUS_OPENGL_INITIALIZATION_FAILED;
    } else {/* NOP */}

    if(EN_SAMPLEAPP_STATUS_SUCCESS == ent_app_return) {
    /* Note: Update the resource structure to get the framebuffer id, width & height  for top view creation
     * stt_vpcore_resource.st_fbo_top_view.u4_id
     * stt_vpcore_resource.st_fbo_top_view.s4_width
     * stt_vpcore_resource.st_fbo_top_view.s4_height
     */
        OpenGLIns.app_gl_get_frameinfo(APP_GL_TOPVIEW, &stt_vpcore_resource.st_fbo_top_view.u4_id, &stt_vpcore_resource.st_fbo_top_view.s4_width, &stt_vpcore_resource.st_fbo_top_view.s4_height);
    /* Note: Update the resource structure to get the framebuffer id, width & height  for contextual view creation
     * stt_vpcore_resource.st_fbo_contextual_view.u4_id
     * stt_vpcore_resource.st_fbo_contextual_view.s4_width
     * stt_vpcore_resource.st_fbo_contextual_view.s4_height
     */
        OpenGLIns.app_gl_get_frameinfo(APP_GL_CUSTOMVIEW, &stt_vpcore_resource.st_fbo_contextual_view.u4_id, &stt_vpcore_resource.st_fbo_contextual_view.s4_width, &stt_vpcore_resource.st_fbo_contextual_view.s4_height);

    /* Step1: Initiate the vpcore functionality using the eng_VPCore_Startup() API.
         * Got the framebuffer id from OpenGL. Start the VP core routine to register the parameters to VPCORE Module. */
        /* Check the return status of eng_VPCore_Startup() and perform the error handling */
    ent_vp_core_return = eng_VPCore_Startup(&stt_vpcore_resource, &stg_camera_pos_param, &stg_vehicle_param);
    if (VP_CORE_RESULT_SUCCESS != ent_vp_core_return)
    {
        printf("main::VPCore Startup Failed Err(%d)\n",ent_vp_core_return);
            ent_app_return = EN_SAMPLEAPP_STATUS_VPCORE_STARTUP_FAILED;
        } else {/* NOP */}
    } else {/* NOP */}

    if(EN_SAMPLEAPP_STATUS_SUCCESS == ent_app_return) {
        while(u4t_loop_num < LOOP_COUNT)
    {
        /* This sample application will display the 3 views of vpcore module.
         * First 3 iteration for standard view.
         * Second 3 iteration for zoom view
         * Last 3 iteration for side view
         */

            if(u4t_loop_num<3)
                ent_vpcore_view = VP_CORE_CONTEXTUAL_VIEW_MODE_REAR_VIEW;
            else if((u4t_loop_num >= 3) & (u4t_loop_num<6))
                ent_vpcore_view = VP_CORE_CONTEXTUAL_VIEW_MODE_ZOOM_VIEW;
            else if((u4t_loop_num >= 6) & (u4t_loop_num<9))
                ent_vpcore_view = VP_CORE_CONTEXTUAL_VIEW_MODE_SIDE_VIEW;
        else
                ent_vpcore_view = VP_CORE_CONTEXTUAL_VIEW_MODE_REAR_VIEW;

            for (unsigned int i = 0; i < VEHICLE_INFO_NUM; i++)
    {

                if(EN_SAMPLEAPP_STATUS_SUCCESS == ent_app_return){
                    ent_app_return = Util.GetFileName(as1t_Camera_image_name, i,as1t_FileName);
                }else {/* NOP */}

                if(EN_SAMPLEAPP_STATUS_SUCCESS == ent_app_return){
                    ent_app_return = Util.LoadBitmap_24RGB(as1t_FileName, IMAGE_WIDTH, IMAGE_HEIGHT, sizeof(au1t_vp_camera_image),au1t_vp_camera_image);
                }else {/* NOP */}

                if(EN_SAMPLEAPP_STATUS_SUCCESS != ent_app_return){
                    ent_vp_core_return = eng_VPCore_Release();
                    /* Check the return status of eng_VPCore_Release() and perform the error handling */
                    if (VP_CORE_RESULT_SUCCESS != ent_vp_core_return) {
                        ent_app_return = EN_SAMPLEAPP_STATUS_VPCORE_RELEASE_FAILED;
                        printf("main::VPCore eng_VPCore_Release Failed Err(%d)\n",ent_vp_core_return);
                    }
                } else {
                    stt_img.pau1_img  = au1t_vp_camera_image;
            stt_img.s4_width  = IMAGE_WIDTH;
            stt_img.s4_height = IMAGE_HEIGHT;

            /* Step2: Call eng_VPCore_UpdateViews() API to process the image.
                     * ent_vpcore_view   : View Mode (zoom,side or standard view)
             * ast_vehicle_info : Vechile information ST_VP_CORE_VEHICLE_INFO(CAN DATA).
             *                    For more information on ST_VP_CORE_VEHICLE_INFO refer vp_core_typedefs.h
             * stt_img          : Image sturcture
             */
                    /* Check the return status of eng_VPCore_UpdateViews() and perform the error handling */
                    ent_vp_core_return = eng_VPCore_UpdateViews(ent_vpcore_view, &ast_vehicle_info[i], &stt_img);
                    if (VP_CORE_RESULT_SUCCESS != ent_vp_core_return) {
            printf("main::VPCore UpdateViews Failed Err(%d)\n",ent_vp_core_return);
                        ent_app_return = EN_SAMPLEAPP_STATUS_VPCORE_UPDATE_FAILED;
                    } else {/* NOP */}
                    if(EN_SAMPLEAPP_STATUS_SUCCESS == ent_app_return) {
        /* Update screen */
                        OpenGLIns.app_gl_draw();
                        OpenGLIns.app_gl_swapbuffers();
                    } else {/* NOP */}
                }
                if(EN_SAMPLEAPP_STATUS_SUCCESS != ent_app_return) {
                    break;
                } else {/* NOP */}
    }
        /* Reset the VPCore module to start the new iterations.
         * This function call is mandatory if we need to use VPCore in mutlitple loops. */
            /* Check the return status of eng_VPCore_Reset() and perform the error handling */
        ent_vp_core_return = eng_VPCore_Reset();
            if (VP_CORE_RESULT_SUCCESS != ent_vp_core_return) {
            printf("main::VPCore eng_VPCore_Reset Failed Err(%d)\n",ent_vp_core_return);
                ent_app_return = EN_SAMPLEAPP_STATUS_VPCORE_RESET_FAILED;
            } else {/* NOP */}
            if(EN_SAMPLEAPP_STATUS_SUCCESS != ent_app_return) {
                break;
            } else {/* NOP */}
            u4t_loop_num++;
    }
    /* Release the VPCore resources. */
        /* Check the return status of eng_VPCore_Release() and perform the error handling */
    ent_vp_core_return = eng_VPCore_Release();
        if (VP_CORE_RESULT_SUCCESS != ent_vp_core_return) {
        printf("main::VPCore eng_VPCore_Release Failed Err(%d)\n",ent_vp_core_return);
            ent_app_return = EN_SAMPLEAPP_STATUS_VPCORE_RELEASE_FAILED;
        } else {/* NOP */}
    } else {/* NOP */}
    Util.DisplayErrorMessage(ent_app_return);

    if(EN_SAMPLEAPP_STATUS_OPENGL_INITIALIZATION_FAILED != ent_app_return){
        OpenGLIns.app_gl_term_opengl();
    } else {/* NOP */}

#ifndef DESKTOP_BUILD_WINDOWS
    system("stty cooked echo");
#endif
	return 0;
}
