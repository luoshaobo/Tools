/************************************************************************************************/
/* Name         : main.cpp                                                                      */
/* Content      : Main function for vpcore test application based on V4.0 software release      */
/* Note         : Sample application for demonstrating the VP1 Software usage                   */
/* Version      : V1.00  25-09-2014   Johnson George           Initial version for V4 Release.  */
/************************************************************************************************/

#include <stdio.h>
#include "openglutlity.h"
#include "utility.h"
#include "vpcore_setting.h"

/*==============================================================================================*/
/* Definitions                                                                                  */
/*==============================================================================================*/
#define TOP_MAP_FILENAME        "TopMap.dat"
#define SIDE_MAP_FILENAME       "SideMap.dat"
#define ZOOM_MAP_FILENAME       "ZoomMap.dat"
#define STANDARD_MAP_FILENAME   "StandardMap.dat"

#define FACTORY_CALIB_FILE      "Image_for_factory_calibration.bmp"
#define UPDATE_VIEW_IMAGE_PRE   "/media/1F89-2D6A/DENSO/dealership_1/Data_"
#define DEALER_CALIB_IMAGE_PRE  "/media/1F89-2D6A/DENSO/dealership_1/Data_"

/*==============================================================================================*/
/* Enums                                                                                  */
/*==============================================================================================*/

/*==============================================================================================*/
/* Variables                                                                                    */
/*==============================================================================================*/
static U1       au1g_vpcore_view_mem[VP_CORE_RAM_SIZE_VIEW];
static U1       au1g_vpcore_calib_mem[VP_CORE_RAM_SIZE_CALIB];
static U1       au1g_side_map[VP_CORE_SIDE_VIEW_MAP_SIZE];
static U1       au1g_std_map[VP_CORE_STD_VIEW_MAP_SIZE];
static U1       au1g_zoom_map[VP_CORE_ZOOM_VIEW_MAP_SIZE];
static U1       au1g_top_map[VP_CORE_TOP_VIEW_MAP_SIZE];

static U1       ulg_view_init_status;
static U1       ulg_calib_init_status;

openglutlity    g_OpenGLIns;
utility         g_Util;

/*==============================================================================================*/
/* Prototypes                                                                                   */
/*==============================================================================================*/

/* Function to initialize the camera parameter */
static void InitializeCameraParameter(
    ST_VP_CORE_CAMERA_POS_INFO *pst_camera_param        /* [in]: Camera parameter initialization*/
);

/* Function to initialize the vehicle parameter */
static void InitializeVehicleParameter(
    ST_VP_CORE_VEHICLE_PARAM *pst_vehicle_param         /* [in]: Vehicle parameter initialization*/
);

/* Function to initialize the tunning parameter */
static void InitializeTunningParameter(
    ST_VP_CORE_VIEW_TUNING_PARAM *pst_side_view_tuning_parameters,     /* [in]: Tunning parameter initialization*/
    ST_VP_CORE_VIEW_TUNING_PARAM *pst_std_view_tuning_parameters       /* [in]: Tunning parameter initialization*/
);

/* Function to initialize the view parameter */
static EN_SAMPLEAPP_ERRORCODE InitializeViewParamater(
    ST_VP_CORE_VIEW_PARAM *pst_vpcore_view_param         /* [in]: View parameter for vpcore view initialization */
);

/* Function to initialize the calibration parameter */
static void InitializeCalibrationParameter(
    ST_VP_CORE_CALIB_PARAM *pst_vpcore_calib_param      /* [in]: Calibration parameter for vpcore calib initialization*/
);

static void InitializeMapObject(
    ST_VP_CORE_VIEW_MAP_OBJ *pcst_view_map_obj          /* [in]: View map object for map loading */
);

/* Function to store the map to file */
static EN_SAMPLEAPP_ERRORCODE LoadMap(
    ST_VP_CORE_VIEW_MAP_OBJ *pcst_view_map              /* [in]: View map object */
);

/* Function to store the map to file */
static EN_SAMPLEAPP_ERRORCODE StoreMap(
    const ST_VP_CORE_VIEW_MAP_OBJ *pcst_view_map        /* [in]: View map object */
);

/* Function to process the update view request */
static EN_SAMPLEAPP_ERRORCODE ProcessUpdateView();

/* Function to process the dealer calibration request */
static EN_SAMPLEAPP_ERRORCODE ProcessDealerCalibration();

/* Function to process the update factory calibration request */
static EN_SAMPLEAPP_ERRORCODE ProcessFactoryCalibration();

/* Function to create the default view maps */
static EN_SAMPLEAPP_ERRORCODE CreateDefaultViewMaps();

/*==============================================================================================*/
/* Codes                                                                                        */
/*==============================================================================================*/

/*----------------------------------------------------------------------------------------------*/
/* Public                                                                                       */
/*----------------------------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------------------------*/
/* Private                                                                                      */
/*----------------------------------------------------------------------------------------------*/

/* Entry Point of the vpcore sample application */
int main(int argc, char* argv[])
{
    BL                              blt_return_status = 0;
    S4                              s4t_vp_core_return = VP_CORE_RESULT_SUCCESS;
    ST_VP_CORE_VIEW_PARAM           stt_vpcore_view_param;
    ST_VP_CORE_CALIB_PARAM          stt_vpcore_calib_param;
    EN_SAMPLEAPP_ERRORCODE          ent_app_return = EN_SAMPLEAPP_STATUS_SUCCESS;
    EN_SAMPLEAPP_ERRORCODE          ent_startup_check = EN_SAMPLEAPP_STATUS_SUCCESS;

    int runMode = 0;
    #define DEALER_CALIBRATION  (1)
    #define FACTORY_CALIBRATION (2)
    #define CREATE_DEFAULT_MAP  (3)
    #define RUN_VPCORE_LIB      (4)

    if (argc < 2)
    {
        printf("\n");
        printf("USAGE: vpcore_sample -dcal -fcal -map -run\n");
        printf("Please choose one these modes:\n");
        printf("-dcal: selects dealership calibration.\n");
        printf("-fcal: selects factory calibration.\n");
        printf("-map:  creates default maps and store into files.\n");
        printf("-run:  runs the vpcore library (vpsm does not run).\n");
        printf("\n");
        exit(0);
    }
    else
    {
        for (int i = 1; i < argc; i++)
        {
            if (!strcmp(argv[i], "-dcal"))
            {
                runMode = DEALER_CALIBRATION;
            }
            else if (!strcmp(argv[i], "-fcal"))
            {
                runMode = FACTORY_CALIBRATION;
            }
            else if (!strcmp(argv[i], "-map"))
            {
                runMode = CREATE_DEFAULT_MAP;
            }
            else if (!strcmp(argv[i], "-run"))
            {
                runMode = RUN_VPCORE_LIB;
            }
            else
            {
                printf("Unknown argument: %s\n", argv[i]);
            }
        }
    }

    memset(&stt_vpcore_calib_param,0,sizeof(ST_VP_CORE_CALIB_PARAM));
    memset(&stt_vpcore_view_param,0,sizeof(ST_VP_CORE_VIEW_PARAM));

    /* View initialization flag */
    ulg_view_init_status    = CALIBRATION_INITIALIZATION_NOT_COMPLETED;
    /* Calibration initialization flag */
    ulg_calib_init_status   = VIEW_INITIALIZATION_NOT_COMPLETED;
#ifndef DESKTOP_BUILD_WINDOWS
    system("stty raw -echo");
#endif

    /* OpenGL Initialization */
    blt_return_status = g_OpenGLIns.app_gl_init_opengl();
    if(false == blt_return_status)
    {
        printf("main::OpenGL Initialization Failed err(%d)\n",blt_return_status);
        ent_app_return = EN_SAMPLEAPP_STATUS_OPENGL_INITIALIZATION_FAILED;
    } else { /* N.O.P */ }

    if(ent_app_return == EN_SAMPLEAPP_STATUS_SUCCESS)
    {
        /* Initialize the view parameter */
        ent_startup_check = InitializeViewParamater(
                                &stt_vpcore_view_param     /* View parameter for initialization of vpcore module. */
                            );
        if(ent_startup_check == EN_SAMPLEAPP_STATUS_SUCCESS)
        {
            /* Initialize the view parameter for using the vpcore view module.*/
            /* Check the return status of s4g_VPCore_View_Startup() and should not perform view operation if any error is reported */
            s4t_vp_core_return = s4g_VPCore_View_Startup(
                                     &stt_vpcore_view_param         /* View parameter for initialization of vpcore module. */
                                 );
            if (s4t_vp_core_return == VP_CORE_RESULT_SUCCESS)
            {
                ulg_view_init_status = VIEW_INITIALIZATION_COMPLETED;
            }
            else
            {
                printf("main::s4g_VPCore_View_Startup Failed Err(%ld)\n",s4t_vp_core_return);
            }
        } else { /* N.O.P */ }

        /* Initialize the calibration parameter */
        InitializeCalibrationParameter(
            &stt_vpcore_calib_param         /* Calibration parameter for initialization of vpcore module. */
        );

        /* Initialize the calibration parameter for using the vpcore view module.*/
        /* Check the return status of s4g_VPCore_Startup() and perform the error handling */
        s4t_vp_core_return = s4g_VPCore_Calib_Startup(
                                 &stt_vpcore_calib_param        /* Calibration parameter for initialization of vpcore module. */
                             );
        if (s4t_vp_core_return == VP_CORE_RESULT_SUCCESS)
        {
            ulg_calib_init_status = CALIBRATION_INITIALIZATION_COMPLETED;
        }
        else
        {
            printf("main::s4g_VPCore_Calib_Startup Failed Err(%ld)\n",s4t_vp_core_return);
        }

        switch (runMode)
        {
        case DEALER_CALIBRATION:
            ent_app_return = ProcessDealerCalibration();
            break;
        case FACTORY_CALIBRATION:
            ent_app_return = ProcessFactoryCalibration();
            break;
        case CREATE_DEFAULT_MAP:
            ent_app_return = CreateDefaultViewMaps();
            break;
        case RUN_VPCORE_LIB:
            ent_app_return = ProcessUpdateView();
            break;
        default:
            printf("An invalid run mode has been selected.\n");
            ent_app_return = EN_SAMPLEAPP_STATUS_FAILED;
            break;
        }

        /* Display the error from the previous call */
        g_Util.DisplayErrorMessage(
            ent_app_return
        );
    } else { /* N.O.P */ }

    /* Release the VPCore resources. */
    /* Check the return status of s4g_VPCore_Release() and perform the error handling */
    s4t_vp_core_return = s4g_VPCore_Release();
    if (VP_CORE_RESULT_SUCCESS != s4t_vp_core_return)
    {
        printf("main::VPCore s4g_VPCore_Release Failed Err(%ld)\n",s4t_vp_core_return);
        ent_app_return = EN_SAMPLEAPP_STATUS_VPCORE_RELEASE_FAILED;
    }
    else
    {
        ent_app_return = EN_SAMPLEAPP_STATUS_SUCCESS;
    }

    if(EN_SAMPLEAPP_STATUS_OPENGL_INITIALIZATION_FAILED != ent_app_return)
    {
        g_OpenGLIns.app_gl_term_opengl();
    } else { /* N.O.P */ }

#ifndef DESKTOP_BUILD_WINDOWS
    system("stty cooked echo");
#else
    Sleep(10000);
#endif
    return 0;
}

/************************************************************************************************/
/* Name         : InitializeCameraParameter                                                     */
/* Function     : Function to initialize the camera parameter                                   */
/* Argument     : pst_camera_param     : [in] Camera parameter setting                          */
/* Return values: None                                                                          */
/* Note         :                                                                               */
/* remarks      :                                                                               */
/* version      : V1.10         Johnson G          Initial Version                              */
/************************************************************************************************/
static void InitializeCameraParameter(
    ST_VP_CORE_CAMERA_POS_INFO *pst_camera_param    /* [in]: Camera parameter initialization*/
)
{
    /* Update the camera parameter */
    pst_camera_param->f4_x      = CAMERA_PARAM_X_POSITION;
    pst_camera_param->f4_y      = CAMERA_PARAM_Y_POSITION;
    pst_camera_param->f4_z      = CAMERA_PARAM_Z_POSITION;
    pst_camera_param->f4_roll   = CAMERA_PARAM_ROLL_ANGLE;
    pst_camera_param->f4_pitch  = CAMERA_PARAM_PITCH;
    pst_camera_param->f4_yaw    = CAMERA_PARAM_YAW;
    return;
}

/************************************************************************************************/
/* Name         : InitializeVehicleParameter                                                    */
/* Function     : Function to initialize the vehicle parameter                                  */
/* Argument     : pst_vehicle_param     : [in] Vehicle parameter setting                        */
/* Return values: None                                                                          */
/* Note         :                                                                               */
/* remarks      :                                                                               */
/* version      : V1.10         Johnson G          Initial Version                              */
/************************************************************************************************/
static void InitializeVehicleParameter(
    ST_VP_CORE_VEHICLE_PARAM *pst_vehicle_param     /* [in]: Vehicle parameter initialization*/
)
{
    /* Update the vehicle information */
    pst_vehicle_param->s4_front_overhang              = VEHICLE_PARAM_FRONT_OVERHANG;
    pst_vehicle_param->s4_rear_overhang               = VEHICLE_PARAM_REAR_OVERHANG;
    pst_vehicle_param->s4_vehicle_width               = VEHICLE_PARAM_WIDTH;
    pst_vehicle_param->s4_wheelbase                   = VEHICLE_PARAM_WHEELBASE;
    pst_vehicle_param->u4_max_linear_steering_angle   = VEHICLE_PARAM_MAX_LINER_STEER_ANGLE;
    pst_vehicle_param->u4_max_linear_wheel_angle      = VEHICLE_PARAM_MAX_LINEAR_WHEEL_ANGLE;
    pst_vehicle_param->u4_max_steering_angle          = VEHICLE_PARAM_MAX_STEER_ANGLE;
    pst_vehicle_param->u4_max_wheel_angle             = VEHICLE_PARAM_MAX_WHEEL_ANGLE;
    pst_vehicle_param->u4_rear_bumper_edge_height     = VEHICLE_PARAM_REAR_BUMPER_EDGE_HEIGHT;
    pst_vehicle_param->u4_trailer_hook_height         = VEHICLE_TRAILER_HOOK_HEIGHT;
    pst_vehicle_param->u4_trailer_hook_length         = VEHICLE_TRAILER_HOOK_LENGTH;
    pst_vehicle_param->u4_wheel_circumference         = VEHICLE_PARAM_WHEEL_CIRCUMFRENCE;
    pst_vehicle_param->u4_wheel_pulse_number          = VEHICLE_PARAM_WHEEL_PULSE;
    return;
}

/************************************************************************************************/
/* Name         : InitializeTunningParameter                                                    */
/* Function     : Function to initialize the tunning parameter                                  */
/* Argument     : pst_side_view_tuning_parameters    : [in] side view tunning parameter         */
/*              : pst_std_view_tuning_parameters     : [in] Standard view tunning parameter     */
/* Return values: None                                                                          */
/* Note         :                                                                               */
/* remarks      :                                                                               */
/* version      : V1.10         Johnson G          Initial Version                              */
/************************************************************************************************/
static void InitializeTunningParameter(
    ST_VP_CORE_VIEW_TUNING_PARAM *pst_side_view_tuning_parameters,     /* [in]: Tunning parameter initialization*/
    ST_VP_CORE_VIEW_TUNING_PARAM *pst_std_view_tuning_parameters       /* [in]: Tunning parameter initialization*/
)
{
    /* Update the enlargement factor */
    pst_side_view_tuning_parameters->en_view_vert_enlarge_origin   = VP_CORE_ENLARGE_ORIGIN_TOP;
    pst_side_view_tuning_parameters->u1_view_horz_enlarge_ratio    = 100;
    pst_side_view_tuning_parameters->u1_view_vert_enlarge_ratio    = 100;

    pst_std_view_tuning_parameters->en_view_vert_enlarge_origin    = VP_CORE_ENLARGE_ORIGIN_TOP;
    pst_std_view_tuning_parameters->u1_view_horz_enlarge_ratio     = 100;
    pst_std_view_tuning_parameters->u1_view_vert_enlarge_ratio     = 100;
    return;
}

/************************************************************************************************/
/* Name         : InitializeViewParamater                                                       */
/* Function     : Function to intialize the view parameter                                      */
/* Argument     : pst_vpcore_view_param  : [in] View parameter settting                         */
/* Return values: Status of operation                                                           */
/* Note         : TBD                                                                           */
/* remarks      : TBD                                                                           */
/* version      : V1.10         Johnson G          Initial Version                              */
/************************************************************************************************/
static EN_SAMPLEAPP_ERRORCODE InitializeViewParamater(
    ST_VP_CORE_VIEW_PARAM *pst_vpcore_view_param         /* [in]: View parameter for vpcore view initialization */
)
{
    EN_SAMPLEAPP_ERRORCODE  ent_return_status = EN_SAMPLEAPP_STATUS_SUCCESS;

    /* Map the buffer for view map object */
    InitializeMapObject(
        &pst_vpcore_view_param->st_view_map_obj      /* View map object */
    );

    /* Get the framebuffer id for the source image & update it to the view paramater */
    /* Update the Framebuffer information for top & custom view */
    g_OpenGLIns.app_gl_get_frameinfo(
        APP_GL_TOPVIEW,
        &pst_vpcore_view_param->st_fbo_top_view.u4_id,
        &pst_vpcore_view_param->st_fbo_top_view.s4_width,
        &pst_vpcore_view_param->st_fbo_top_view.s4_height
    );

    g_OpenGLIns.app_gl_get_frameinfo(
        APP_GL_CUSTOMVIEW,
        &pst_vpcore_view_param->st_fbo_contextual_view.u4_id,
        &pst_vpcore_view_param->st_fbo_contextual_view.s4_width,
        &pst_vpcore_view_param->st_fbo_contextual_view.s4_height
    );
    /* Update the Framebuffer information for captured image */
    g_OpenGLIns.app_gl_get_frameinfo(
        APP_GL_CAM_IMAGE,
        &pst_vpcore_view_param->st_fbo_captured_img.u4_id,     /* Framebuffer id for captured image */
        &pst_vpcore_view_param->st_fbo_captured_img.s4_width,  /* Framebuffer width for captured image */
        &pst_vpcore_view_param->st_fbo_captured_img.s4_height  /* Framebuffer height for captured image */
    );

    /* Allocate the memory pool for view processing */
    memset(au1g_vpcore_view_mem,0,VP_CORE_RAM_SIZE_VIEW);
    pst_vpcore_view_param->st_memory_pool.pu1_buffer   = au1g_vpcore_view_mem;
    pst_vpcore_view_param->st_memory_pool.s4_size      = VP_CORE_RAM_SIZE_VIEW;

    /* Update the guideline parameter to view parameter */
    pst_vpcore_view_param->st_gdl_param.st_distance_line_rear_color_0_3.u1_r = DISTANCE_START_LINE_TRAJECTORY_R_INDEX;
    pst_vpcore_view_param->st_gdl_param.st_distance_line_rear_color_0_3.u1_g = DISTANCE_START_LINE_TRAJECTORY_G_INDEX;
    pst_vpcore_view_param->st_gdl_param.st_distance_line_rear_color_0_3.u1_b = DISTANCE_START_LINE_TRAJECTORY_B_INDEX;
    pst_vpcore_view_param->st_gdl_param.st_distance_line_rear_color_0_3.u1_a = DISTANCE_START_LINE_TRAJECTORY_A_INDEX;

    pst_vpcore_view_param->st_gdl_param.st_distance_line_rear_color_1.u1_r   = DISTANCE_MIDDLE_LINE_TRAJECTORY_R_INDEX;
    pst_vpcore_view_param->st_gdl_param.st_distance_line_rear_color_1.u1_g   = DISTANCE_MIDDLE_LINE_TRAJECTORY_G_INDEX;
    pst_vpcore_view_param->st_gdl_param.st_distance_line_rear_color_1.u1_b   = DISTANCE_MIDDLE_LINE_TRAJECTORY_B_INDEX;
    pst_vpcore_view_param->st_gdl_param.st_distance_line_rear_color_1.u1_a   = DISTANCE_MIDDLE_LINE_TRAJECTORY_A_INDEX;

    pst_vpcore_view_param->st_gdl_param.st_distance_line_rear_color_2.u1_r   = DISTANCE_REAR_LINE_TRAJECTORY_R_INDEX;
    pst_vpcore_view_param->st_gdl_param.st_distance_line_rear_color_2.u1_g   = DISTANCE_REAR_LINE_TRAJECTORY_G_INDEX;
    pst_vpcore_view_param->st_gdl_param.st_distance_line_rear_color_2.u1_b   = DISTANCE_REAR_LINE_TRAJECTORY_B_INDEX;
    pst_vpcore_view_param->st_gdl_param.st_distance_line_rear_color_2.u1_a   = DISTANCE_START_LINE_TRAJECTORY_A_INDEX;

    pst_vpcore_view_param->st_gdl_param.st_trajectory_line_rear_color.u1_r   = TRAJECTORY_LINE_R_INDEX;
    pst_vpcore_view_param->st_gdl_param.st_trajectory_line_rear_color.u1_g   = TRAJECTORY_LINE_G_INDEX;
    pst_vpcore_view_param->st_gdl_param.st_trajectory_line_rear_color.u1_b   = TRAJECTORY_LINE_B_INDEX;
    pst_vpcore_view_param->st_gdl_param.st_trajectory_line_rear_color.u1_a   = TRAJECTORY_LINE_A_INDEX;

    pst_vpcore_view_param->st_gdl_param.u1_distance_line_width_0_3           = DISTANCE_START_LINE_WIDTH_IN_PIXEL;
    pst_vpcore_view_param->st_gdl_param.u1_distance_line_width_1             = DISTANCE_MIDDLE_LINE_WIDTH_IN_PIXEL;
    pst_vpcore_view_param->st_gdl_param.u1_distance_line_width_2             = DISTANCE_REAR_LINE_WIDTH_IN_PIXEL;
    pst_vpcore_view_param->st_gdl_param.u1_trajectory_line_width             = TRAJECTORY_LINE_WIDTH_IN_PIXEL;

    /* Update the map object for side map creation */
    ent_return_status = LoadMap(
                            &pst_vpcore_view_param->st_view_map_obj          /* View map object */
                        );

    if(ent_return_status == EN_SAMPLEAPP_STATUS_SUCCESS)
    {
        /* Update the view control parameters for controlling the brightness */
        pst_vpcore_view_param->st_view_control_param.u1_brightness_limit_diff        = VIEW_CONTROL_BRIGHTNESS_LIMIT_DIFF;
        pst_vpcore_view_param->st_view_control_param.u1_target_brightness            = VIEW_CONTROL_TARGET_BRIGHTNESS;
    } else { /* N.O.P */ }

    return ent_return_status;
}


/************************************************************************************************/
/* Name         : InitializeCalibrationParameter                                                */
/* Function     : Function to initialize the calibration parameter                              */
/* Argument     : pst_vpcore_calib_param     : [in] Calibration parameter setting for startup    */
/* Return values: None                                                                          */
/* Note         :                                                                               */
/* remarks      :                                                                               */
/* version      : V1.10         Johnson G          Initial Version                              */
/************************************************************************************************/
static void InitializeCalibrationParameter(
    ST_VP_CORE_CALIB_PARAM *pst_vpcore_calib_param           /* [in]: Calibration parameter for vpcore calib initialization*/
)
{
    memset(au1g_vpcore_calib_mem,0,VP_CORE_RAM_SIZE_CALIB);
    pst_vpcore_calib_param->st_memory_pool.pu1_buffer   = au1g_vpcore_calib_mem;
    pst_vpcore_calib_param->st_memory_pool.s4_size      = VP_CORE_RAM_SIZE_CALIB;

    /* Initialize the camera parameter */
    InitializeCameraParameter(
        &pst_vpcore_calib_param->st_camera_param_design
    );

    /* Initialize the vehicle parameter */
    InitializeVehicleParameter(
        &pst_vpcore_calib_param->st_vehicle_param
    );

    /* Initialize the tunning parameter */
    InitializeTunningParameter(
        &pst_vpcore_calib_param->st_side_view_tuning_parameters,
        &pst_vpcore_calib_param->st_std_view_tuning_parameters
    );

    /* Get the framebuffer id for the source image & update it to the calib paramater */
    g_OpenGLIns.app_gl_get_frameinfo(
        APP_GL_CAM_IMAGE,
        &pst_vpcore_calib_param->st_fbo_captured_img.u4_id,     /* Framebuffer id for captured image */
        &pst_vpcore_calib_param->st_fbo_captured_img.s4_width,  /* Framebuffer width for captured image */
        &pst_vpcore_calib_param->st_fbo_captured_img.s4_height  /* Framebuffer height for captured image */
    );

    /* Update the target pattern info to calibration parameter */
    pst_vpcore_calib_param->st_target_info.st_left_pattern.st_coordinate_rb.s4_x         = CALIB_TARGET_INFO_LEFT_RB_s4_x;
    pst_vpcore_calib_param->st_target_info.st_left_pattern.st_coordinate_rb.s4_y         = CALIB_TARGET_INFO_LEFT_RB_s4_y;
    pst_vpcore_calib_param->st_target_info.st_left_pattern.st_coordinate_rt.s4_x         = CALIB_TARGET_INFO_LEFT_RT_s4_x;
    pst_vpcore_calib_param->st_target_info.st_left_pattern.st_coordinate_rt.s4_y         = CALIB_TARGET_INFO_LEFT_RT_s4_y;
    pst_vpcore_calib_param->st_target_info.st_left_pattern.st_coordinate_lb.s4_x         = CALIB_TARGET_INFO_LEFT_LB_s4_x;
    pst_vpcore_calib_param->st_target_info.st_left_pattern.st_coordinate_lb.s4_y         = CALIB_TARGET_INFO_LEFT_LB_s4_y;
    pst_vpcore_calib_param->st_target_info.st_left_pattern.st_coordinate_lt.s4_x         = CALIB_TARGET_INFO_LEFT_LT_s4_x;
    pst_vpcore_calib_param->st_target_info.st_left_pattern.st_coordinate_lt.s4_y         = CALIB_TARGET_INFO_LEFT_LT_s4_y;

    pst_vpcore_calib_param->st_target_info.st_middle_pattern.st_coordinate_rb.s4_x       = CALIB_TARGET_INFO_MIDDLE_RB_s4_x;
    pst_vpcore_calib_param->st_target_info.st_middle_pattern.st_coordinate_rb.s4_y       = CALIB_TARGET_INFO_MIDDLE_RB_s4_y;
    pst_vpcore_calib_param->st_target_info.st_middle_pattern.st_coordinate_rt.s4_x       = CALIB_TARGET_INFO_MIDDLE_RT_s4_x;
    pst_vpcore_calib_param->st_target_info.st_middle_pattern.st_coordinate_rt.s4_y       = CALIB_TARGET_INFO_MIDDLE_RT_s4_y;
    pst_vpcore_calib_param->st_target_info.st_middle_pattern.st_coordinate_lb.s4_x       = CALIB_TARGET_INFO_MIDDLE_LB_s4_x;
    pst_vpcore_calib_param->st_target_info.st_middle_pattern.st_coordinate_lb.s4_y       = CALIB_TARGET_INFO_MIDDLE_LB_s4_y;
    pst_vpcore_calib_param->st_target_info.st_middle_pattern.st_coordinate_lt.s4_x       = CALIB_TARGET_INFO_MIDDLE_LT_s4_x;
    pst_vpcore_calib_param->st_target_info.st_middle_pattern.st_coordinate_lt.s4_y       = CALIB_TARGET_INFO_MIDDLE_LT_s4_y;

    pst_vpcore_calib_param->st_target_info.st_right_pattern.st_coordinate_rb.s4_x        = CALIB_TARGET_INFO_RIGHT_RB_s4_x;
    pst_vpcore_calib_param->st_target_info.st_right_pattern.st_coordinate_rb.s4_y        = CALIB_TARGET_INFO_RIGHT_RB_s4_y;
    pst_vpcore_calib_param->st_target_info.st_right_pattern.st_coordinate_rt.s4_x        = CALIB_TARGET_INFO_RIGHT_RT_s4_x;
    pst_vpcore_calib_param->st_target_info.st_right_pattern.st_coordinate_rt.s4_y        = CALIB_TARGET_INFO_RIGHT_RT_s4_y;
    pst_vpcore_calib_param->st_target_info.st_right_pattern.st_coordinate_lb.s4_x        = CALIB_TARGET_INFO_RIGHT_LB_s4_x;
    pst_vpcore_calib_param->st_target_info.st_right_pattern.st_coordinate_lb.s4_y        = CALIB_TARGET_INFO_RIGHT_LB_s4_y;
    pst_vpcore_calib_param->st_target_info.st_right_pattern.st_coordinate_lt.s4_x        = CALIB_TARGET_INFO_RIGHT_LT_s4_x;
    pst_vpcore_calib_param->st_target_info.st_right_pattern.st_coordinate_lt.s4_y        = CALIB_TARGET_INFO_RIGHT_LT_s4_y;

    pst_vpcore_calib_param->u4_rear_domain_top_view_height                               = VIEW_CONTROL_TOP_VIEW_HEIGHT;
    return;
}

/************************************************************************************************/
/* Name         : InitializeMapObject                                                           */
/* Function     : Function to initialize the view map structure                                 */
/* Argument     : pcst_view_map_obj : [in] View map structure                                   */
/* Return values: None                                                                          */
/* Note         :                                                                               */
/* remarks      :                                                                               */
/* version      : V1.10         Johnson G          Initial Version                              */
/************************************************************************************************/
static void InitializeMapObject(
    ST_VP_CORE_VIEW_MAP_OBJ *pcst_view_map_obj      /* [in]: View map object for map loading */
)
{
    /* Initialize the View MAP object */
    memset(au1g_side_map,0,sizeof(au1g_side_map));
    memset(au1g_std_map,0,sizeof(au1g_std_map));
    memset(au1g_top_map,0,sizeof(au1g_top_map));
    memset(au1g_zoom_map,0,sizeof(au1g_zoom_map));

    pcst_view_map_obj->st_side_map.pu1_buffer = au1g_side_map;
    pcst_view_map_obj->st_side_map.s4_size    = sizeof(au1g_side_map);

    pcst_view_map_obj->st_std_map.pu1_buffer  = au1g_std_map;
    pcst_view_map_obj->st_std_map.s4_size     = sizeof(au1g_std_map);

    pcst_view_map_obj->st_top_map.pu1_buffer  = au1g_top_map;
    pcst_view_map_obj->st_top_map.s4_size     = sizeof(au1g_top_map);

    pcst_view_map_obj->st_zoom_map.pu1_buffer = au1g_zoom_map;
    pcst_view_map_obj->st_zoom_map.s4_size    = sizeof(au1g_zoom_map);

    return;
}

/************************************************************************************************/
/* Name         : LoadMap                                                                       */
/* Function     : Function to load the map from file                                            */
/* Argument     : pcst_view_map     : [in] View map structure                                   */
/* Return values: status of operation                                                           */
/* Note         :                                                                               */
/* remarks      :                                                                               */
/* version      : V1.10         Johnson G          Initial Version                              */
/************************************************************************************************/
static EN_SAMPLEAPP_ERRORCODE LoadMap(
    ST_VP_CORE_VIEW_MAP_OBJ *pcst_view_map          /* [in]: View map object */
)
{
    EN_SAMPLEAPP_ERRORCODE  ent_return_status = EN_SAMPLEAPP_STATUS_SUCCESS;

    if(ent_return_status == EN_SAMPLEAPP_STATUS_SUCCESS)
    {
        ent_return_status = g_Util.LoadMapFromFile(
                                SIDE_MAP_FILENAME,                        /* Side map file name                               */
                                pcst_view_map->st_side_map.pu1_buffer,    /* Side map buffer to hold the side map data        */
                                pcst_view_map->st_side_map.s4_size);      /* Side map size                                    */
    } else { /* N.O.P */ }
    if(ent_return_status == EN_SAMPLEAPP_STATUS_SUCCESS)
    {
        ent_return_status = g_Util.LoadMapFromFile(
                                ZOOM_MAP_FILENAME,                        /* Zoom map file name                               */
                                pcst_view_map->st_zoom_map.pu1_buffer,    /* Zoom map buffer to hold the zoom map data        */
                                pcst_view_map->st_zoom_map.s4_size);      /* Zoom map size                                    */
    } else { /* N.O.P */ }
    if(ent_return_status == EN_SAMPLEAPP_STATUS_SUCCESS)
    {
        ent_return_status = g_Util.LoadMapFromFile(
                                STANDARD_MAP_FILENAME,                    /* Standard map file name                           */
                                pcst_view_map->st_std_map.pu1_buffer,     /* Standard buffer to hold the top map data         */
                                pcst_view_map->st_std_map.s4_size);       /* Standard map size                                */
    } else { /* N.O.P */ }
    if(ent_return_status == EN_SAMPLEAPP_STATUS_SUCCESS)
    {
        ent_return_status = g_Util.LoadMapFromFile(
                                TOP_MAP_FILENAME,                         /* Top map file name                                */
                                pcst_view_map->st_top_map.pu1_buffer,     /* Top buffer to hold the top map data              */
                                pcst_view_map->st_top_map.s4_size);       /* Top map size                                     */
    } else { /* N.O.P */ }

    return ent_return_status;
}

/************************************************************************************************/
/* Name         : StoreMap                                                                      */
/* Function     : Function to store the map to a file                                           */
/* Argument     : pcst_view_map         : [in] View map structure                               */
/* Return values: status of operation                                                           */
/* Note         :                                                                               */
/* remarks      :                                                                               */
/* version      : V1.10         Johnson G          Initial Version                              */
/************************************************************************************************/
static EN_SAMPLEAPP_ERRORCODE StoreMap(
    const ST_VP_CORE_VIEW_MAP_OBJ *pcst_view_map              /* [in]: View map object */
)
{
    EN_SAMPLEAPP_ERRORCODE  ent_return_status = EN_SAMPLEAPP_STATUS_SUCCESS;
    if(ent_return_status == EN_SAMPLEAPP_STATUS_SUCCESS)
    {
        ent_return_status = g_Util.StoreMapToFile(
                                SIDE_MAP_FILENAME,                        /* Side map file name in which map data to be stored      */
                                pcst_view_map->st_side_map.pu1_buffer,    /* Side map buffer which hold the side map data           */
                                VP_CORE_SIDE_VIEW_MAP_SIZE);              /* Side map size                                          */
    } else { /* N.O.P */ }
    if(ent_return_status == EN_SAMPLEAPP_STATUS_SUCCESS)
    {
        ent_return_status = g_Util.StoreMapToFile(
                                ZOOM_MAP_FILENAME,                        /* Zoom map file name in which map data to be stored      */
                                pcst_view_map->st_zoom_map.pu1_buffer,    /* Zoom map buffer which hold the zoom map data           */
                                VP_CORE_ZOOM_VIEW_MAP_SIZE);              /* Zoom map size                                          */
    } else { /* N.O.P */ }
    if(ent_return_status == EN_SAMPLEAPP_STATUS_SUCCESS)
    {
        ent_return_status = g_Util.StoreMapToFile(
                                STANDARD_MAP_FILENAME,                    /* Standard map file name in which map data to be stored  */
                                pcst_view_map->st_std_map.pu1_buffer,     /* Standard map buffer which hold the standard map data   */
                                VP_CORE_STD_VIEW_MAP_SIZE);               /* Standard map size                                      */
    } else { /* N.O.P */ }
    if(ent_return_status == EN_SAMPLEAPP_STATUS_SUCCESS)
{
        ent_return_status = g_Util.StoreMapToFile(
                                TOP_MAP_FILENAME,                         /* Top map file name in which map data to be stored       */
                                pcst_view_map->st_top_map.pu1_buffer,     /* Top map buffer which hold the Top map data             */
                                VP_CORE_TOP_VIEW_MAP_SIZE);               /* Top map size                                           */
    } else { /* N.O.P */ }
    return ent_return_status;
}



/************************************************************************************************/
/* Name         : ProcessUpdateView                                                             */
/* Function     : Function  to perform the update view                                          */
/* Argument     : None                                                                          */
/* Return values: Status of operation                                                           */
/* Note         :                                                                               */
/* remarks      :                                                                               */
/* version      : V1.10         Johnson G          Initial Version                              */
/************************************************************************************************/
static EN_SAMPLEAPP_ERRORCODE ProcessUpdateView()
{
    U1                              au1t_vp_camera_image[IMAGE_WIDTH * IMAGE_HEIGHT * 3] = {0};
    EN_SAMPLEAPP_ERRORCODE          ent_app_return = EN_SAMPLEAPP_STATUS_SUCCESS;
    EN_VP_CORE_CONTEXTUAL_VIEW_MODE ent_vpcore_view = VP_CORE_CONTEXTUAL_VIEW_MODE_REAR_VIEW;
    U4                              u4t_loop_num = 0;
    S1                              as1t_FileName[MAX_FILE_NAME_SIZE] = {0};
    S4                              s4t_vp_core_return = VP_CORE_RESULT_SUCCESS;
    U1                              u1t_hist_trans = 100;
    U4                              u4t_image_timestamp = 0;
    U4                              u4t_pulse_timestamp = 0;

    if(ulg_view_init_status == VIEW_INITIALIZATION_COMPLETED)
    {
        while(u4t_loop_num < LOOP_COUNT)
        {
            /* This sample application will display the 3 views of vpcore module.
             * First 3 iteration for standard view.
             * Second 3 iteration for zoom view
             * Last 3 iteration for side view
             */

            if(u4t_loop_num<3)
                ent_vpcore_view = VP_CORE_CONTEXTUAL_VIEW_MODE_REAR_VIEW;
            else if((u4t_loop_num >= 3) & (u4t_loop_num<6))
                ent_vpcore_view = VP_CORE_CONTEXTUAL_VIEW_MODE_ZOOM_VIEW;
            else if((u4t_loop_num >= 6) & (u4t_loop_num<9))
                ent_vpcore_view = VP_CORE_CONTEXTUAL_VIEW_MODE_SIDE_VIEW;
            else
                ent_vpcore_view = VP_CORE_CONTEXTUAL_VIEW_MODE_REAR_VIEW;

            for (unsigned int i = 0; i < VEHICLE_INFO_NUM; i++)
            {
                if(EN_SAMPLEAPP_STATUS_SUCCESS == ent_app_return)
                {
                    ent_app_return = g_Util.GetFileName(
                                         (S1*)UPDATE_VIEW_IMAGE_PRE,    /* Prefix of the image file along with path information */
                                         i,
                                         as1t_FileName                  /* Buffer to hold the file name */
                                     );
                } else { /* N.O.P */ }

                if(EN_SAMPLEAPP_STATUS_SUCCESS == ent_app_return)
                {
                    ent_app_return = g_Util.LoadBitmap_24RGB(
                                         as1t_FileName,                 /* BMP file name */
                                         IMAGE_WIDTH,                   /* Image Width */
                                         IMAGE_HEIGHT,                  /* Image Height */
                                         sizeof(au1t_vp_camera_image),  /* Size of the image buffer */
                                         au1t_vp_camera_image           /* Buffer to hold the BMP image data */
                                     );
                    /* This is to handle the case where the frame number is less than the can data */
                    if((i>0) && (EN_SAMPLEAPP_STATUS_SUCCESS != ent_app_return)) {
                        printf("Less Frame than the CAN Data, Continue to show the different view\n");
                        ent_app_return = EN_SAMPLEAPP_STATUS_SUCCESS;
                        break;
                    } else { /* N.O.P */ }
                } else { /* N.O.P */ }

                if(EN_SAMPLEAPP_STATUS_SUCCESS == ent_app_return)
                {
                        /* Load the camera image to framebuffer */
                    g_OpenGLIns.app_update_cam_img(
                        au1t_vp_camera_image            /* Image data buffer for loading it to GPU memory */
                    );

                    /* Currently the image time stamp & pulse time stamp is not provided from CAN data.*/
                    /* Once it is supported from CAN data the below calculation can be removed */
                    ast_vehicle_info[i].u4_img_timestamp    = u4t_image_timestamp;
                    ast_vehicle_info[i].u4_pulse_timestamp  = u4t_pulse_timestamp;

                    u4t_image_timestamp += 50;
                    u4t_pulse_timestamp += 50;

                    /* Step2: Call s4g_VPCore_UpdateViews() API to process the image.
                     * ent_vpcore_view   : View Mode (zoom,side or standard view)
                     * ast_vehicle_info  : Vechile information ST_VP_CORE_VEHICLE_INFO(CAN DATA).
                     *                    For more information on ST_VP_CORE_VEHICLE_INFO refer vp_core_typedefs.h
                     * u1t_hist_trans    : Transperancy for the history view
                     */
                     /* Check the return status of s4g_VPCore_UpdateViews() and perform the error handling */
                    s4t_vp_core_return = s4g_VPCore_UpdateViews(
                                             ent_vpcore_view,           /* View type */
                                             &ast_vehicle_info[i],      /* Vehicle information */
                                             u1t_hist_trans             /* History transparency factor (0-100%) */
                                         );

                    if (VP_CORE_RESULT_SUCCESS != s4t_vp_core_return)
                    {
                    printf("main::VPCore UpdateViews Failed Err(%ld)\n",s4t_vp_core_return);
                        ent_app_return = EN_SAMPLEAPP_STATUS_VPCORE_UPDATE_FAILED;
                    } else { /* N.O.P */ }
                    if(EN_SAMPLEAPP_STATUS_SUCCESS == ent_app_return)
                    {
                        /* Update screen */
                        g_OpenGLIns.app_gl_draw();
                        g_OpenGLIns.app_gl_swapbuffers();
                    } else { /* N.O.P */ }
                } else { /* N.O.P */ }
                if(EN_SAMPLEAPP_STATUS_SUCCESS != ent_app_return)
                {
                    break;
                } else { /* N.O.P */ }
            }
            /* Reset the VPCore module to start the new iterations.
             * This function call is mandatory if we need to use VPCore in mutlitple loops. */
            /* Check the return status of s4g_VPCore_Reset() and perform the error handling */
            s4t_vp_core_return = s4g_VPCore_Reset();
            if (VP_CORE_RESULT_SUCCESS != s4t_vp_core_return)
            {
                printf("main::VPCore s4g_VPCore_Reset Failed Err(%ld)\n",s4t_vp_core_return);
                ent_app_return = EN_SAMPLEAPP_STATUS_VPCORE_RESET_FAILED;
            } else { /* N.O.P */ }

            if(EN_SAMPLEAPP_STATUS_SUCCESS != ent_app_return)
            {
                break;
            } else { /* N.O.P */ }
            u4t_loop_num++;
        }
    }
    else
    {
        ent_app_return = EN_SAMPLEAPP_VIEW_NOT_INITIALIZED;
        printf("VIEW INITIALIZATION NOT PERFORMED \n");
    }
    return ent_app_return;
}

/************************************************************************************************/
/* Name         : ProcessDealerCalibration                                                      */
/* Function     : Function  to perform the dealer calibration                                   */
/* Argument     : None                                                                          */
/* Return values: Status of operation                                                           */
/* Note         :                                                                               */
/* remarks      :                                                                               */
/* version      : V1.10         Johnson G          Initial Version                              */
/************************************************************************************************/
static EN_SAMPLEAPP_ERRORCODE ProcessDealerCalibration()
{
    EN_SAMPLEAPP_ERRORCODE      ent_app_return = EN_SAMPLEAPP_STATUS_SUCCESS;
    ST_VP_CORE_CAMERA_POS_INFO  stt_camera_pos_result;
    ST_VP_CORE_VIEW_MAP_OBJ     stt_view_map_obj;
    EN_VP_CORE_CALIB_STATUS     ent_calib_status;
    S4                          s4t_vp_core_return = VP_CORE_RESULT_SUCCESS;
    S1                          as1t_FileName[MAX_FILE_NAME_SIZE] = {0};
    U2                          u2t_vehicle_speed = 0; /*TBD: For supporting from can.h file */
    U1                          au1t_vp_camera_image[IMAGE_WIDTH * IMAGE_HEIGHT * 3] = {0};

    if(ulg_calib_init_status == CALIBRATION_INITIALIZATION_COMPLETED)
    {
        InitializeMapObject(
            &stt_view_map_obj
        );

        for (unsigned int i = 0; i < VEHICLE_INFO_NUM; i++)
        {
            u2t_vehicle_speed = u2_vehicle_speed[i];                /* Reading the speed from the can_v4.0.h file. This is created manually */
            if(EN_SAMPLEAPP_STATUS_SUCCESS == ent_app_return)
            {
                ent_app_return = g_Util.GetFileName(
                                     (S1*)DEALER_CALIB_IMAGE_PRE,   /* Prefix of the image file along with path information */
                                     i,
                                     as1t_FileName                  /* Buffer to hold the file name */
                                 );
            } else { /* N.O.P */ }

            if(EN_SAMPLEAPP_STATUS_SUCCESS == ent_app_return)
            {
                ent_app_return = g_Util.LoadBitmap_24RGB(
                                     as1t_FileName,                 /* BMP file name */
                                     IMAGE_WIDTH,                   /* Image width */
                                     IMAGE_HEIGHT,                  /* Image Height */
                                     sizeof(au1t_vp_camera_image),  /* Size of Image buffer */
                                     au1t_vp_camera_image           /* Buffer to hold the BMP image data */
                                 );
            } else { /* N.O.P */ }

            if(EN_SAMPLEAPP_STATUS_SUCCESS == ent_app_return)
            {
                    /* Load the camera image to framebuffer */
                g_OpenGLIns.app_update_cam_img(
                    au1t_vp_camera_image            /* Image data buffer for loading it to GPU memory */
                );

                s4t_vp_core_return = s4g_VPCore_CalibrateCameraInDealer(
                                         &ast_vehicle_info[i],              /* [in] Vehicle information */
                                         u2t_vehicle_speed,                 /* [in] Vehicle Speed       */
                                         &stt_camera_pos_result,            /* [out] Calibrated camera poistion */
                                         &stt_view_map_obj,                 /* [out] View map object */
                                         &ent_calib_status                  /* [out] Calibration status */
                                 );

                printf("Dealer Calibration State:(%d) Return(%ld) Speed(%d) Steer(%ld)\n",ent_calib_status,s4t_vp_core_return,u2t_vehicle_speed,ast_vehicle_info[i].s4_steer);
                if (VP_CORE_RESULT_SUCCESS != s4t_vp_core_return)
                {
                    printf( "DEALER CAMERA CALIBRATION FAILED\n" );
                    ent_app_return = EN_SAMPLEAPP_STATUS_VPCORE_DEALER_CALIB_FAILED;
                    break;
                } else { /* N.O.P */ }

                if(ent_calib_status == VP_CORE_CALIB_STATUS_COMPLETE)
                {
                    printf( "DEALER CAMERA CALIBRATION OUTPUT\n" );
                    printf( "    CAMERA X     = %f\n", stt_camera_pos_result.f4_x );
                    printf( "    CAMERA Y     = %f\n", stt_camera_pos_result.f4_y );
                    printf( "    CAMERA Z     = %f\n", stt_camera_pos_result.f4_z );
                    printf( "    CAMERA PITCH = %f\n", stt_camera_pos_result.f4_pitch );
                    printf( "    CAMERA ROLL  = %f\n", stt_camera_pos_result.f4_roll );
                    printf( "    CAMERA YAW   = %f\n", stt_camera_pos_result.f4_yaw );
                    ent_app_return = StoreMap(
                                         &stt_view_map_obj   /* View map object */
                                     );
                    break;
                } else { /* N.O.P */ }
            } else { /* N.O.P */ }
        }
    }
    else
    {
        ent_app_return = EN_SAMPLEAPP_CALIBRATION_NOT_INITIALIZED;
        printf( "CALIBRATION INITIALIZATION NOT PERFORMED \n" );
    }
    return ent_app_return;
}

/************************************************************************************************/
/* Name         : ProcessFactoryCalibration                                                      */
/* Function     : Function  to perform the factory calibration                                  */
/* Argument     : None                                                                          */
/* Return values: Status of operation                                                           */
/* Note         :                                                                               */
/* remarks      :                                                                               */
/* version      : V1.10         Johnson G          Initial Version                              */
/************************************************************************************************/
static EN_SAMPLEAPP_ERRORCODE ProcessFactoryCalibration()
{
    EN_SAMPLEAPP_ERRORCODE      ent_app_return = EN_SAMPLEAPP_STATUS_SUCCESS;
    ST_VP_CORE_CAMERA_POS_INFO  stt_camera_pos_result;
    ST_VP_CORE_VIEW_MAP_OBJ     stt_view_map_obj;
    S4                          s4t_vp_core_return = VP_CORE_RESULT_SUCCESS;
    U1                          au1t_vp_camera_image[IMAGE_WIDTH * IMAGE_HEIGHT * 3] = {0};

    if(ulg_calib_init_status == CALIBRATION_INITIALIZATION_COMPLETED)
    {
        InitializeMapObject(
            &stt_view_map_obj    /* View map object */
        );

        /* Load bitmap file */
        ent_app_return = g_Util.LoadBitmap_24RGB(
                             (S1*)FACTORY_CALIB_FILE,       /* BMP file name for calibration */
                             IMAGE_WIDTH,                   /* Image width */
                             IMAGE_HEIGHT,                  /* Image Height */
                             sizeof(au1t_vp_camera_image),  /* Size of buffer */
                             au1t_vp_camera_image           /* Buffer to hold the file name */
                         );
        if(EN_SAMPLEAPP_STATUS_SUCCESS == ent_app_return)
        {
            /* Load the camera image to framebuffer */
            g_OpenGLIns.app_update_cam_img(
                au1t_vp_camera_image            /* Image data buffer for loading it to GPU memory */
            );

            s4t_vp_core_return = s4g_VPCore_CalibrateCameraInPlant(
                                     &stt_camera_pos_result,        /* [out] Calibrated camera poistion */
                                     &stt_view_map_obj              /* [out] View map object */
                                 );

            if (VP_CORE_RESULT_SUCCESS != s4t_vp_core_return)
            {
                printf( "FACTORY CAMERA CALIBRATION FAILED\n" );
                printf("main::VPCore s4g_VPCore_CalibrateCameraInPlant Failed Err(%ld)\n",s4t_vp_core_return);
                ent_app_return = EN_SAMPLEAPP_STATUS_VPCORE_FACTORY_CALIB_FAILED;
            }
            else
            {
                printf( "FACTORY CAMERA CALIBRATION OUTPUT\n" );
                printf( "    CAMERA X     = %f\n", stt_camera_pos_result.f4_x );
                printf( "    CAMERA Y     = %f\n", stt_camera_pos_result.f4_y );
                printf( "    CAMERA Z     = %f\n", stt_camera_pos_result.f4_z );
                printf( "    CAMERA PITCH = %f\n", stt_camera_pos_result.f4_pitch );
                printf( "    CAMERA ROLL  = %f\n", stt_camera_pos_result.f4_roll );
                printf( "    CAMERA YAW   = %f\n", stt_camera_pos_result.f4_yaw );
                ent_app_return = StoreMap(
                                     &stt_view_map_obj       /* View map object */
                                 );
#ifdef DESKTOP_BUILD_WINDOWS
                Sleep(10000);
#endif
            }
        } else { /* N.O.P */ }
    }
    else
    {
        ent_app_return = EN_SAMPLEAPP_CALIBRATION_NOT_INITIALIZED;
        printf( "CALIBRATION INITIALIZATION NOT PERFORMED \n" );
    }
    return ent_app_return;
}

/************************************************************************************************/
/* Name         : CreateDefaultViewMaps                                                         */
/* Function     : Function  to perform the default view map creation                            */
/* Argument     : None                                                                          */
/* Return values: Status of operation                                                           */
/* Note         :                                                                               */
/* remarks      :                                                                               */
/* version      : V1.10         Johnson G          Initial Version                              */
/************************************************************************************************/
static EN_SAMPLEAPP_ERRORCODE CreateDefaultViewMaps()
{
    EN_SAMPLEAPP_ERRORCODE          ent_app_return = EN_SAMPLEAPP_STATUS_SUCCESS;
    ST_VP_CORE_CAMERA_POS_INFO      stt_camera_pos;
    ST_VP_CORE_VIEW_MAP_OBJ         stt_view_map_obj;
    ST_VP_CORE_VIEW_TUNING_PARAM    stt_std_view_tuning_param;
    ST_VP_CORE_VIEW_TUNING_PARAM    stt_side_view_tuning_param;
    ST_VP_CORE_VEHICLE_PARAM        stt_vehicle_param;
    S4                              s4t_vp_core_return = VP_CORE_RESULT_SUCCESS;

    /* Initialize the map object */
    InitializeMapObject(
        &stt_view_map_obj    /* View map object */
    );

    /* Initialize the camera parameter */
    InitializeCameraParameter(
        &stt_camera_pos
    );

    /* Initialize the vehicle parameter */
    InitializeVehicleParameter(
        &stt_vehicle_param
    );

    /* Initialize the side & standard tunning parameter */
    InitializeTunningParameter(
        &stt_side_view_tuning_param,
        &stt_std_view_tuning_param
    );

    s4t_vp_core_return = s4g_VPCore_Create_Default_View_Maps(
                             &stt_camera_pos,                       /* [out] Calibrated camera poistion */
                             &stt_std_view_tuning_param,            /* [in] standard tunning parameter */
                             &stt_side_view_tuning_param,           /* [in] side tunning parameter */
                             &stt_vehicle_param,                    /* [in] Vehicle parameter */
                             VIEW_CONTROL_TOP_VIEW_HEIGHT,          /* [in] Rear domain height */
                             &stt_view_map_obj                      /* [out] view map */
                         );

    if (VP_CORE_RESULT_SUCCESS != s4t_vp_core_return)
    {
        printf( "DEFAULT MAP CREATION FAILED\n" );
        printf("main::VPCore s4g_VPCore_Create_Default_View_Maps Failed Err(%ld)\n",s4t_vp_core_return);
        ent_app_return = EN_SAMPLEAPP_DEFAULT_MAP_CREATION_FAILED;
    }
    else
    {
        ent_app_return = StoreMap(
                             &stt_view_map_obj       /* View map object */
                         );
    }
    return ent_app_return;
}
