#ifndef OPENGLUTLITY_H
#define OPENGLUTLITY_H

/************************************************************************************************/
/* Name         : openglutility.h                                                               */
/* Content      : Helper function for opengl interfaces                                         */
/* Note         :                                                                               */
/* Version      : V1.00  31-07-2014   Johnson George           Initial version.                 */
/************************************************************************************************/

#include <string.h>
#include <math.h>
#include <assert.h>
#include <GLES2/gl2.h>
#include <EGL/egl.h>
#include "vp_types.h"
#include "opengldefs.h"
#include "windowutility.h"

#define app_gl_ortho2D(left, right, bottom, top, mat)	app_gl_ortho((left), (right), (bottom), (top), -1.0f, 1.0f, (mat))

class openglutlity
{
private:
    GLuint m_app_tpv_texture;
    GLuint m_app_ctv_texture;
    GLuint m_app_cam_img_texture;
    GLuint m_app_frame_texture;
    GLuint m_app_tpv_framebuf;
    GLuint m_app_ctv_framebuf;
    GLuint m_app_cam_img_framebuf;
    S4	m_app_ScreenWidth, m_app_ScreenHeight;
    EXT_GL_MATRIX m_app_projMat;
    EGLDisplay	m_gl_Display;                               /* EGL display connection */
    EGLSurface	m_gl_Surface;                               /* EGL drawing surface */
    EGLContext	m_gl_Context;                               /* EGL rendering context */
    S4 m_app_programObj[APP_GL_SHDPG_NUM];
    APP_GL_PG_LOCATION m_app_programLoc[APP_GL_SHDPG_NUM];	/* Index of various variable of the shader program */

    GLuint app_gl_LoadShader(GLenum type, const char *shaderSrc);
    void app_gl_load_identity(EXT_GL_MATRIX* mat);
    void app_egl_err_handler(EGLint egl_err);
    void app_gl_ortho(GLfloat glf_left, GLfloat glf_right, GLfloat glf_bottom, GLfloat glf_top, GLfloat glf_near_z, GLfloat glf_far_z, EXT_GL_MATRIX* mat);
    void app_gl_polygon(GLuint gli_texture, GLfloat* glf_vertices, GLfloat* glf_vTexCoord, S4 s4_num, BL bl_blend, S4 s4_type, GLfloat* glf_projMatrix);
    GLuint app_gl_createTexture(U1* u1_texture, U2 u2_width, U2 u2_height, S4 s4_format, S4 s4_filter, S4 s4_wrap);
    GLuint app_gl_createFrameBuffer(S4 s4_width, S4 s4_height, S4 s4_targetTextureId);
    BL app_gl_TexShader();
public:
    windowutility m_windowutil;

    openglutlity();
    BL app_gl_init_opengl();
    void app_gl_term_opengl();
    void app_gl_draw();
    void app_gl_swapbuffers();
    void app_gl_get_frameinfo(AppGlViewType glviewtype_type, U4 *u4_id, S4 *s4_width, S4 *s4_height);
    void app_update_cam_img(U1 *pu1_data);
};

#endif // OPENGLUTLITY_H
